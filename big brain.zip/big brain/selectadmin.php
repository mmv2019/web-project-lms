<?php  
session_start();
 $connect = mysqli_connect("localhost", "root", "", "bigbrain");  
 $output = '';  
 $sql = "SELECT * FROM customers where ut='ad' And  id != {$_SESSION['id']}  ";  
 $result = mysqli_query($connect, $sql);  
 $output .= '  
      <div id="myTable" class="table-responsive " style="width:100%">  
           <table class="table table-bordered">  
                <tr>  
                     <th >id</th>  
                     <th >name</th>  
                     <th >email</th>
                     <th >datejoined</th>  
                     <th >Delete</th>  
                </tr>';  
 $rows = mysqli_num_rows($result);
 if($rows > 0)  
 {  
	  if($rows > 10)
	  {
		  $delete_records = $rows - 10;
		  $delete_sql = "DELETE FROM customers LIMIT $delete_records";
		  mysqli_query($connect, $delete_sql);
	  }
      while($row = mysqli_fetch_array($result))  
      {  
           $output .= '  
                <tr>  
                     <td>'.$row["id"].'</td>  
                     <td class="name" data-id1="'.$row["id"].'" >'.$row["name"].'</td>  
                     <td class="email" data-id2="'.$row["id"].'" >'.$row["email"].'</td> 
                     <td class="datejoined" data-id3="'.$row["id"].'" >'.$row["datejoined"].'</td>  
                     <td><button type="button" name="delete_btn" data-id3="'.$row["id"].'" class="btn btn-xs btn-danger btn_delete">x</button></td>  
                </tr>  
           ';  
      }  
      $output .= '  
           <tr>  
                <td></td>  
                <td id="name" contenteditable></td>  
                <td  id="email" contenteditable></td>
                <td id="datejoined" ></td>  
                <td><button type="button" name="btn_add" id="btn_add" class="btn btn-xs btn-success">+</button></td>  
           </tr>  
      ';  
 }  
 else  
 {  
      $output .= '
				<tr>  
					<td></td>  
					<td id="name" contenteditable></td>  
					<td  id="email" contenteditable></td>  
					<td><button type="button" name="btn_add" id="btn_add" class="btn btn-xs btn-success">+</button></td>  
			   </tr>';  
 }  
 $output .= '</table>  
      </div>';  
 echo $output;  
 ?>