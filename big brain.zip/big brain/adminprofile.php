<?php
session_start();
if ($_SESSION['ut'] != 'ad') {
    header('Location:./user-type.php');
    exit;
}
$Email = $_SESSION['email'];
$Name = $_SESSION['name'];
$no = $_SESSION['phoneno'];
$img = $_SESSION['image'];
$datejoined = $_SESSION['datejoined'];

?>

<!DOCTYPE html>
<html>

<title></title>
<link rel="shortcut icon" type="image/png" href="logo1.png">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-teal.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans'>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<!-- CSS vertical tab -->
<link rel="stylesheet" href="vertical-tab-admin.css">

<!-- M3RFSH BTO3 EH DOL BS MARYAM HATAHOM -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/themes/smoothness/jquery-ui.min.css"/>
<!--<link rel="stylesheet" href="fontawesome/css/all.css">
        <link rel="stylesheet" href="fontawesome/css/all.min.css"> -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- datejoined icon -->
<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
<script src="adminprofile.js"></script>


<style>
    html, body, h1, h2, h3, h4, h5 {
        font-family: "Open Sans", sans-serif
    }


</style>
<body class="w3-theme-14">

<!-- Navbar -->
<div class="w3-top">
    <div class="w3-bar w3-theme-d2 w3-left-align w3-large">
        <a class="w3-bar-item w3-button w3-hide-medium w3-hide-large w3-right w3-padding-large w3-large w3-theme-teal"
           href="javascript:void(0);" onclick="openNav()"><i class="fa fa-bars"></i></a>
        <a href="homee.php" class="w3-bar-item w3-button w3-padding-large w3-hover-white"><i
                    class="fa fa-home w3-margin-right"></i>BigBrain</a>

        <a href="account settings.php" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-red"
           title="Account Settings"><i class="fas fa-user-cog"></i></a>
        <a href="chat/index.php" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-red"
           title="Messages"><i class="fas fa-comment-dots"></i></a>
        <div class="w3-dropdown-hover w3-hide-small w3-hover-white">
        </div>
        <a href="sign out.php" class="w3-bar-item w3-button w3-hide-small w3-right w3-padding-large "
           title="sign out"><i class="fas fa-sign-out-alt"></i></a>
        <a href="#" class="w3-bar-item w3-button w3-hide-small w3-right w3-padding-large w3-hover-white"
           title="My Account">
            <img src="<?php echo $img; ?>" class="w3-circle" style="height:23px;width:23px" alt="Avatar">
        </a>
    </div>
</div>

<!-- Navbar on small screens -->
<div id="navDemo" class="w3-bar-block w3-theme-d2 w3-hide w3-hide-large w3-hide-medium w3-large">
    <a href="#" class="w3-bar-item w3-button w3-padding-large">Link 1</a>
    <a href="#" class="w3-bar-item w3-button w3-padding-large">Link 2</a>
    <a href="#" class="w3-bar-item w3-button w3-padding-large">Link 3</a>
    <a href="#" class="w3-bar-item w3-button w3-padding-large">My Profile</a>
</div>

<!-- Page Container -->
<div class="w3-container w3-content" style="max-width:1400px;margin-top:80px">
    <!-- The Grid -->
    <div class="w3-row">
        <!-- Left Column -->
        <div class="w3-col m3">
            <!-- Profile -->
            <div class="w3-card w3-round w3-white">
                <div class="w3-container">
                    <h4 class="w3-center">My Profile</h4>
                    <p class="w3-center"><img src="<?php echo $img; ?>" class="w3-circle"
                                              style="height:106px;width:106px" alt="Avatar"></p>
                    <hr>

                    <p><i class="fa fa-id-card fa-fw w3-margin-right w3-text-theme"></i> <?php echo $Name; ?></p>
                    <p><i class="fa fa-envelope fa-fw w3-margin-right w3-text-theme"></i> <?php echo $Email ?></p>
                    <p>
                        <i class="fas fa-calendar fa-fw w3-margin-right w3-text-theme"></i> <?php echo $_SESSION["datejoined"]; ?>
                    </p>
                </div>
            </div>
            <br>

            <!-- Accordion -->
            <div class="w3-card w3-round w3-theme-d1 tab">
                <div class="w3-theme">
                    <button onclick="openTAB(event, 'admins')"
                            class=" tablinks w3-button w3-block w3-theme-d1 w3-left-align"><i
                                class="fa fa-user-plus fa-fw w3-margin-right"></i>Admins
                    </button>

                    <button onclick="openTAB(event, 'cc')" id="defaultOpen"
                            class="tablinks w3-button w3-block w3-theme-d1 w3-left-align"><i
                                class="fa fa-list-ul fa-fw w3-margin-right"></i> All Courses
                    </button>

                    <button onclick="openTAB(event, 'students')"
                            class="tablinks w3-button w3-block w3-theme-d1 w3-left-align"><i
                                class="fa fa-users fa-fw w3-margin-right"></i> All Students
                    </button>

                </div>
            </div>
        </div>
        <br>

        <!-- End Left Column -->
        <!-- </div> -->


        <!-- <div class="w3-col m7 " style="margin-left:25%; padding-top:0px;"> -->

        <?php
        // include 'viewandeditadmins.php';
        //include 'coursesforadmin.php';
        ?>
        <!-- Button trigger modal -->
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"
                style="float:right; background-color:teal;padding:10px">
            View Warnings
        </button>

        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
             aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Warnings</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        ...
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>


        <!-- <div class="w3-col m7 " style="margin-left:25%; padding-top:0px;"> -->

        <?php
        // include 'viewandeditadmins.php';
        //include 'coursesforadmin.php';
        ?>

        <div id="admins" class="tabcontent">
            <h3>Admins</h3>
            <i class="fa fa-search"></i> <!-- width:5% -->
            <input style="width: 90%; padding: 12px 20px 12px 40px; border: 1px solid #ddd;"
                   type="text" id="myInput" onkeyup="Search();" placeholder="Search by Email.." title="Type in a name">
            <script>
                function Search() {
                    var input, filter, table, tr, td, i, txtValue;
                    input = document.getElementById("myInput");
                    filter = input.value.toUpperCase();
                    table = document.getElementById("myTable");
                    tr = table.getElementsByTagName("tr");
                    for (i = 0; i < tr.length; i++) {
                        td = tr[i].getElementsByTagName("td")[2];
                        if (td) {
                            txtValue = td.textContent || td.innerText;
                            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                                tr[i].style.display = "";
                            } else {
                                tr[i].style.display = "none";
                            }
                        }
                    }
                }
            </script>
            <br><br>
            <div id="live_data"></div>
            <p>  <?php //include 'viewandeditadmins.php';  ?>
            </p>
        </div>

        <div id="cc" class="tabcontent">
            <h3> All Courses</h3>
            <i class="fa fa-search"></i> <!-- width:5% -->
            <input style="width: 70%; padding: 12px 20px 12px 40px; border: 1px solid #ddd;"
                   type="text" id="Search" onkeyup="Searchfor();" placeholder="Search by Course Name.."
                   title="Type in a courseName">
            <script>
                function Searchfor() {
                    var input, filter, table, tr, td, i, txtValue;
                    input = document.getElementById("Search");
                    filter = input.value.toUpperCase();
                    table = document.getElementById("myCourses");
                    tr = table.getElementsByTagName("tr");
                    for (i = 0; i < tr.length; i++) {
                        td = tr[i].getElementsByTagName("td")[1];
                        if (td) {
                            txtValue = td.textContent || td.innerText;
                            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                                tr[i].style.display = "";
                            } else {
                                tr[i].style.display = "none";
                            }
                        }
                    }
                }</script>
            <br>
            <br>
            <i class="fa fa-search"></i> <!-- width:5% -->
            <input style="width: 70%; padding: 12px 20px 12px 40px; border: 1px solid #ddd;"
                   type="text" id="ins" onkeyup="insearch();" placeholder="Search by instructor.."
                   title="Type in a name">
            <script>
                function insearch() {
                    var input, filter, table, tr, td2, i, txtValue, txtValue2;
                    input = document.getElementById("ins");
                    filter = input.value.toUpperCase();
                    table = document.getElementById("myCourses");
                    tr = table.getElementsByTagName("tr");
                    for (i = 0; i < tr.length; i++) {

                        td2 = tr[i].getElementsByTagName("td")[3];
                        if (td2) {
                            txtValue2 = td2.textContent || td2.innerText;
                            if (txtValue2.toUpperCase().indexOf(filter) > -1) {
                                tr[i].style.display = "";
                            } else {
                                tr[i].style.display = "none";
                            }
                        }
                    }
                }

            </script>
            <br><br>
            <div id="live_data_courses">
            </div>
            <p> <?php //include 'coursesforadmin.php';  ?> </p>
        </div>

        <div id="students" class="tabcontent">
            <h3>Students</h3>
            <p> <?php include 'viewallstudents.php'; ?> </p>
        </div>


        <script>
            function openTAB(evt, tab) {
                var i, tabcontent, tablinks;
                tabcontent = document.getElementsByClassName("tabcontent");
                console.log(tabcontent);
                for (i = 0; i < tabcontent.length; i++) {
                    tabcontent[i].style.display = "none";
                }
                tablinks = document.getElementsByClassName("tablinks");
                for (i = 0; i < tablinks.length; i++) {
                    tablinks[i].className = tablinks[i].className.replace(" active", "");
                }
                document.getElementById(tab).style.display = "block";
                evt.currentTarget.className += " active";
            }

            // Get the element with id="defaultOpen" and click on it
            document.getElementById("defaultOpen").click();
        </script>


    </div> <!-- End Middle Column -->

    <!-- Right Column -->


    <!-- End Right Column -->
</div>

<!-- End Grid -->
</div>

<!-- End Page Container -->
</div>
<br>

<!-- Footer -->
<footer class="w3-container w3-theme-d3 w3-padding-16">
    <h5>Footer</h5>
</footer>


<!--
<script>
// Accordion
function myFunction(id) {
 var x = document.getElementById(id);
 if (x.className.indexOf("w3-show") == -1) {
   x.className += " w3-show";
   x.previousElementSibling.className += " w3-theme-d1";
 } else {
   x.className = x.className.replace("w3-show", "");
   x.previousElementSibling.className =
   x.previousElementSibling.className.replace(" w3-theme-d1", "");
 }
}

// Used to toggle the menu on smaller screens when clicking on the menu button
function openNav() {
 var x = document.getElementById("navDemo");
 if (x.className.indexOf("w3-show") == -1) {
   x.className += " w3-show";
 } else {
   x.className = x.className.replace(" w3-show", "");
 }
}
</script>
-->

</body>
</html>