<?php

session_start();

// initializing variables
$Name = "";
$Email    = "";
$errors = array(); 
$err="";
// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'bigbrain');

// REGISTER USER
if (isset($_POST['reg_user'])) {
  $ut = $_POST['type'];
  $_SESSION['ut']=$ut;
  // receive all input values from the form
  $Name = mysqli_real_escape_string($db, $_POST['Name']);
  $Email = mysqli_real_escape_string($db, $_POST['Email']);
  if(!filter_var($Email,FILTER_VALIDATE_EMAIL)){
		header("Location:sign up and login.php?error=Email Not Valid!");
    exit;
  }
  $img="img/profile.png";
  $phoneno=mysqli_real_escape_string($db, $_POST['phoneno']);
  if($phoneno <= 0){
      array_push($errors, "Phone number cant contain negative numbers.");
      $err.="Phone number cant contain negative numbers.";
  }
  $password_1 = mysqli_real_escape_string($db, $_POST['pass']);
  $password_2 = mysqli_real_escape_string($db, $_POST['conpass']);
  $id=2;
  if ($password_1 != $password_2) {
	array_push($errors, "The two passwords do not match");
  $err.="The two passwords do not match ";
  }

  // first check the database to make sure 
  // a user does not already exist with the same username and/or email
  $user_check_query = "SELECT * FROM customers WHERE email='{$_POST['Email']}' LIMIT 1";
  $result = mysqli_query($db, $user_check_query);
  $user = mysqli_fetch_assoc($result);
  
  if ($user) { // if user exists

    if ($user['email'] === $Email) {
      array_push($errors, "email already exists");
      $err.="email already exists";
      //header('location: sign up and login-admins.php');
    }

  }

  // Finally, register user if there are no errors in the form
  if (count($errors) == 0) {
  	$password =password_hash($password_1,PASSWORD_DEFAULT);//encrypt the password before saving in the database
$datejoined=date("Y-m-d");
  	$query = "INSERT INTO customers (name, email,phoneno, password,ut,img, datejoined) 
  			  VALUES('$Name', '$Email', '$phoneno','$password','$ut','$img', '$datejoined')";
  	mysqli_query($db, $query);
      $_SESSION['success'] = "You are now logged in";
      array_push($errors, "logged in succesfuly");
      $err.="logged in succesfuly";
      $_SESSION['email']=$Email;
      $_SESSION['name']=$Name;
      $_SESSION['phoneno']=$phoneno;
      $_SESSION['id']=$id;
      $_SESSION['image']=$img;
      $_SESSION['datejoined']=$datejoined;
      $_SESSION['ut']=$ut;
      if($ut=='st'){
  	header('Location: profile2.php');
      }
      else if($ut=='in'){
        header('Location: instructorprofile.php');
      }
      else if($ut=='au'){
        header('Location: auditorprofile.php');
      } 
      else if($ut=='hr'){
        header('Location: instructorprofile.php');
      }
  }
}?>
<?php  if (count($errors) > 0) : ?>
    <div class="error">
        <?php foreach ($errors as $error) : ?>
          <p><?php echo "<script>alert('$error');</script>"; ?></p>
        <?php endforeach ?>
    </div>
  <?php if(empty($_SESSION['email']))
  {header('Location: user-type.php?error='.$err);} endif ?>
  <?php 
  ?>