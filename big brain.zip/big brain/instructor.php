<?php 
session_start();
$email=$_SESSION['email'];
$name=$_SESSION['name'];
$no=$_SESSION['phoneno'];
$img=$_SESSION['image'];
?>

<head>
        <meta charset="UTF-8">
        <title> Instructor Profile</title>
        <link rel="shortcut icon" type="image/png" href="logo1.png">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel = "stylesheet" href = "cssinstructor.css">
        <link rel="stylesheet" href="fontawesome/css/all.css">
        <link rel="stylesheet" href="fontawesome/css/all.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/themes/smoothness/jquery-ui.min.css" />

      </head>
<body>
<nav class="navbar w3-teal">
  <div class="container-fluid w3-sand">
    <ul class="nav navbar-nav">
      <li class="active "><a href="#">Browse</a></li>
      <li><a href="#">Profile </a></li>
     
      <li>
<form class="search-box" action="" method ="">
<input type ="text" name="search" value placeholder="search">
<button class="search-btn" type="button" name="button">
 <i class="fas fa-search"></i></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="#"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Log out</a></li>
    </ul>
  </div>
</nav>


    <div class="container">
        <div class="profile-header">
            <div class ="profile-img">
                <img src="<?php echo $img; ?>" width="200" 
                alt="">
            </div>
            <div class="profile-nav-info">
                <h3 class = "user-name"><?php echo $name?></h3>
                <div class="type">
                    <p class="state">student</p>
                </div>

            </div>
            <div class ="profile-option">
                <div class="notification">
                    <i class="fas fa-bell"></i>
                    <span class="alert-message">1</span>
                </div>
            </div>
        </div>
        <div class="main-bd">
            <div class="left-side">
                <div class="profile-side">
                    <p class="mobile-no"><i 
                        class="fa fa-phone">
                        
                    </i><?php echo 0+$no?></p>
                    <p class="user-mail"><i class="fa fa-envelope"><?php echo $email?></i>
                    </p>
                   
                    <div class="profile-btn">
                        <button class="chatbtn">
                            <i class="fas fa-comment"></i> Chat
                        </button>
                        <button class="chatbtn">
                            <i class="fas fa-book"></i> library
                        </button>
                        <button class="createbtn">
                            <i class="fas fa-user-cog"> Settings</i>
                        </button>
                    </div>
                    <!-- add hna-->
                </div>
            </div>
            
       
        <div class="right-side"><div class="nav">
            <ul>
                <li id='p' onclick="tabs(0)" class="user-post active">Progress</li>
                <li id='r' onclick="tabs(1)" class="user-review">Cart</li>
                <li id='s' onclick="tabs(2)" class="user-setting">Wishlist</li>
            </ul>
        </div> 
   
        <div class="profile-body">
            <div class="profile-posts tab">
                <h1>Your Posts</h1>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid aperiam cupiditate ipsum expedita, necessitatibus eius, quasi hic tenetur labore repellat voluptatibus consequuntur debitis sint laboriosam dolore, vel voluptate commodi? Veritatis quae veniam corporis? Iure quae laborum, adipisci nulla cum, iusto deleniti alias quasi expedita officiis corporis cumque dignissimos et delectus tempore corrupti officia ex tenetur. Quaerat eaque sequi quo, aperiam, labore officia numquam fugit suscipit mollitia vel doloribus veritatis odio?</p>
            </div>
            <div class="profile-reviews tab">
                <h1>User Reviews</h1>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. In quasi doloribus, sint ipsum excepturi quis non dolor, sapiente adipisci maiores fugit repellat numquam, laborum voluptate odit architecto reprehenderit! Eius ducimus libero distinctio quia earum, corrupti deserunt! Quod dolorem esse eum maxime quam voluptas earum, quae hic laboriosam quis odit eaque sit corporis, tempore repellat nulla, fugiat similique. Fugiat, nemo labore molestias ad, dignissimos neque, eveniet quia totam commodi voluptate voluptatibus!</p>
            </div>
            <div class="profile-setting tab">
                <h1>Account Settings</h1>
                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Hic exercitationem temporibus quisquam illum iure aliquid recusandae labore alias, veniam maiores assumenda rem mollitia modi eius tempore officiis esse eum cum. Odit tempore quidem, illum recusandae quasi harum earum architecto dicta voluptatum optio ab quod? Voluptas minima ratione dicta voluptatibus quam natus ipsam earum architecto, accusamus necessitatibus quod eligendi nobis odit nulla repellendus vero nemo provident rem adipisci magni laudantium sapiente.</p>
            </div>
         </div>
        </div>
    </div>
    </div>
    <h3 >Courses</h3>
    <div class="w3-row-padding" style="margin:0 -16px">
      <div class="w3-quarter w3-margin-bottom">
        <ul class="w3-ul w3-center w3-card w3-hover-shadow">
          <li class="w3-teal w3-xlarge w3-padding-32">Mechanics</li>
          <img src="img/mechanics.png" width="200" alt=""> 
          <li class="w3-padding-16">Photography</li>
          <li class="w3-padding-16">5GB Storage</li>
          <li class="w3-padding-16">Mail Support</li>
          <li class="w3-padding-16">
            <h2>$ 10</h2>
            <span class="w3-opacity">per month</span>
          </li>
          <li class="w3-teal w3-padding-24">
            <button class="w3-button w3-white w3-padding-large w3-hover-black">Add to cart</button>
          </li>
        </ul>
      </div>

      <div class="w3-quarter w3-margin-bottom">
        <ul class="w3-ul w3-center w3-card w3-hover-shadow">
          <li class="w3-sand w3-xlarge w3-padding-32">IT</li>
          <img src="img/it.png" width="200" alt=""> 
          <li class="w3-padding-16">Photography</li>
          <li class="w3-padding-16">5GB Storage</li>
          <li class="w3-padding-16">Mail Support</li>
          <li class="w3-padding-16">
            <h2>$ 10</h2>
            <span class="w3-opacity">per month</span>
          </li>
          <li class="w3-sand w3-padding-24">
            <button class="w3-button w3-white w3-padding-large w3-hover-black">Add to cart</button>
          </li>
        </ul>
      </div>

      <div class="w3-quarter w3-margin-bottom">
        <ul class="w3-ul w3-center w3-card w3-hover-shadow">
          <li class="w3-teal w3-xlarge w3-padding-32">Security</li>
          <img src="img/security.png" width="200" alt=""> 
          <li class="w3-padding-16">Photography</li>
          <li class="w3-padding-16">5GB Storage</li>
          <li class="w3-padding-16">Mail Support</li>
          <li class="w3-padding-16">
            <h2>$ 10</h2>
            <span class="w3-opacity">per month</span>
          </li>
          <li class="w3-teal w3-padding-24">
            <button class="w3-button w3-white w3-padding-large w3-hover-black">Add to cart</button>
          </li>
        </ul>
      </div>

      <div class="w3-quarter">
        <ul class="w3-ul w3-center w3-card w3-hover-shadow">
          <li class="w3-sand w3-xlarge w3-padding-32">Business</li>
          <img src="img/business.png" width="200" alt=""> 
          <li class="w3-padding-16">Photography</li>
          <li class="w3-padding-16">50GB Storage</li>
          <li class="w3-padding-16">Endless Support</li>
          <li class="w3-padding-16">
            <h2>$ 25</h2>
            <span class="w3-opacity">per month</span>
          </li>
          <li class="w3-sand w3-padding-24">
            <button class="w3-button w3-white w3-padding-large w3-hover-black">Add to cart</button>
          </li>
        </ul>
      </div>

    <script src="./jquery/jquery.js"></script>
    <script src="./main.js"></script>
    <script src="main.js"></script>

</body>