
<?php
if(!isset($_GET['code'])){
    header('Location:./');
}
$code = $_GET['code'];

session_start();
$msg = "";
if(isset($_GET['enroll'])){
    if(!isset($_SESSION['email'])){
        header('Location:./sign up and login.php');
    }
    //*Add to cart
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bigbrain";

// Create connection
$conn= new mysqli($servername, $username, $password, $dbname);
$sql="SELECT * FROM course WHERE code='{$code}'";
$result = mysqli_query($conn,$sql);
?>
<html>
<head>
<title>Course</title><link rel="shortcut icon" type="image/png" href="logo1.png">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link rel="stylesheet" type="text/css" href="css/stylesheet.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
      .course-container{
          margin-top:100px;
      }
</style>
</head>
<body>
<?php include('header.php'); ?>
<?php

while($row = mysqli_fetch_assoc($result)){
?>
<div class="course-container">
    
  <div id="photo">
    <img class="courseimg" src="img/book.jpg">
  </div>
  <div id="section">
    <h2 class="title"><?php echo $row['name'] ?></h2>
    <p class="descrip"><h3><?php echo $row['name'] ?></h3>
    <div class="">
  <a href="?enroll&code=<?php echo $code;?>"><button type="button" class="btn btn-default">ENROLL</button></a>
    </div>
  </div>
  <div id="section1">
    <img class="instructorimg" src="<?php echo $row['img'] ?>">
    <p class="descrip"><?php echo $row['instructor'] ?></p>

  </div>
</div>

<?php } ?>
</body>
</html>
