<?php  
$connect = mysqli_connect("localhost", "root", "", "bigbrain");
$sql = "INSERT INTO course (  name  , price,instructor,description )
VALUES ('$_POST[coursename]', '$_POST[price]','$_POST[instructor]','$_POST[description]')";  
if(mysqli_query($connect, $sql))  
{  
     echo 'Data Inserted';  
}  
 ?>