<?php
$servername="localhost";
$username="root";
$password="";



 $conn= new mysqli($servername,$username,$password,"bigbrain");

  
   $StudentsEmail =$_POST['smail'];
   $reason =$_POST['reasonn'];



   $sql="INSERT INTO miisbehave (StudentsEmail,reason) VALUES('$StudentsEmail', '$reason') ";
   mysqli_query($conn,$sql);
  header('location:auditorprofile.php');
   mysqli_close($conn); 
?>