<?php  
 $connect = mysqli_connect("localhost", "root", "", "bigbrain"); 
 $email= $_POST["email"];
 $name=$_POST["name"];
 $warningreason=$_POST["reason"];
$ids=$_POST["id"];
$warning='1';
 $sql = "UPDATE customers
 SET warning = '{$_POST['reason']}'
 WHERE id = '{$_POST['id']}'";

 mysqli_query($connect,$sql); 
 if( mysqli_query($connect,$sql))  
 {  
    echo '<script>alert("Data has been inserted")</script>'; 
    echo $email."                 ";
 }  
 else{
    echo "Welcome to Geeks for Geeks"; 
 }
 ?>