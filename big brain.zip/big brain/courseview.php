<?php 
session_start();
$email=$_SESSION['email'];
$name=$_SESSION['name'];
$no=$_SESSION['phoneno'];
$img=$_SESSION['image'];
?>
<html>
   
<title> View Course</title>
<meta charset="UTF-8"><link rel="shortcut icon" type="image/png" href="logo1.png">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-teal.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans'>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/themes/smoothness/jquery-ui.min.css" />
<link rel="stylesheet" href="fontawesome/css/all.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
html, body, h1, h2, h3, h4, h5 {font-family: "Open Sans", sans-serif}

.nav{
    width:100%;
    z-index: -1;
    
}
.navbar{
    color:#0c9992;
}
.nav ul{
    display: flex;
    justify-content: center;
    list-style-type: none;
    height: 40px;
    background: #fff;
    box-shadow: 0px 2px 5px rgba(0,0,0,.3);
}



.nav ul li.active,
.tablink:hover{
    box-shadow: 0px -3px 0px teal inset;
    color:tomato;
}
/* Style tab links */
.tablink {

    width:100%;
  background-color: #555;
  color:black;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 14px 16px;
  font-size: 17px;
  width: 25%;
  display: flex;
    justify-content: center;
    list-style-type: none;
    height: 40px;
    background: #fff;
    box-shadow: 0px 2px 5px rgba(0,0,0,.3);
}

.tablink:hover {
  background-color: #777;
}

/* Style the tab content (and add height:100% for full page content) */
.tabcontent {
  color: black;
  display: none;
  padding: 100px 20px;
  height: 100%;
}




</style>
<body class="w3-theme-14">

<!-- Navbar -->

<div class="w3-top">
 <div class="w3-bar w3-theme-d2 w3-left-align w3-large">
  <a class="w3-bar-item w3-button w3-hide-medium w3-hide-large w3-right w3-padding-large w3-large w3-theme-teal" href="javascript:void(0);" onclick="openNav()"><i class="fa fa-bars"></i></a>
  <a href="home.php" class="w3-bar-item w3-button w3-padding-large w3-hover-red"><i class="fa fa-home w3-margin-right"></i>BIG BRAIN</a>
  <a href="#" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-red" title="Account Settings"><i class="fas fa-user-cog"></i></a>
  <a href="#" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-red" title="Messages"><i class="fas fa-comment-dots"></i></a>
  <div class="w3-dropdown-hover w3-hide-small w3-hover-red">
    <button class="w3-button w3-padding-large w3-hover-red" title="Notifications"><i class="fa fa-bell"></i><span class="w3-badge w3-right w3-small w3-green">3</span></button>     
    <div class="w3-dropdown-content w3-card-4 w3-bar-block " style="width:300px">
      <a href="#" class="w3-bar-item w3-button">student enrolled in a course</a>
      <a href="#" class="w3-bar-item w3-button">instructor added new course</a>
      <a href="#" class="w3-bar-item w3-button">student needs help</a>
    </div>
  </div>
  <a href="#" class="w3-bar-item w3-button w3-hide-small w3-right w3-padding-large " title="sign out"><i class="fas fa-sign-out-alt"></i></a>
  <a href="#" class="w3-bar-item w3-button w3-hide-small w3-right w3-padding-large w3-hover-white" title="My Account">
    <img src="<?php echo $img; ?>"  class="w3-circle" style="height:23px;width:23px" alt="Avatar">
  </a>
 </div>
</div>

<!-- Navbar on small screens -->
<div id="navDemo" class="w3-bar-block w3-theme-d2 w3-hide w3-hide-large w3-hide-medium w3-large">
  <a href="#" class="w3-bar-item w3-button w3-padding-large">Link 1</a>
  <a href="#" class="w3-bar-item w3-button w3-padding-large">Link 2</a>
  <a href="#" class="w3-bar-item w3-button w3-padding-large">Link 3</a>
  <a href="#" class="w3-bar-item w3-button w3-padding-large">My Profile</a>
</div>

<!-- Page Container -->
<div class="w3-container w3-content" style="max-width:1400px;margin-top:80px">    
  <!-- The Grid -->
  <div class="w3-row">
    <!-- Left Column -->
    <div class="w3-col m3">
      <!-- Profile -->
      <div class="w3-card w3-round w3-white">
        <div class="w3-container">
         <h4 class="w3-center">My Profile</h4>
         <p class="w3-center"><img src="<?php echo $img; ?>" class="w3-circle" style="height:106px;width:106px" alt="Avatar"></p>
         <hr>
         <p><i class="fa fa-pencil fa-fw w3-margin-right w3-text-theme"></i><?php echo $name?></p>
         <p><i class="fas fa-at fa-fw w3-margin-right w3-text-theme"></i> <?php echo $email?></p>
         <p><i class="far fa-clock fa-fw w3-margin-right w3-text-theme"></i> <?php echo $datejoined?></p>
        </div>
      </div>
      <br>
      
      <!-- Accordion -->
      <div class="w3-card w3-round w3-theme-d1">
        <div class="w3-theme">
       
         
          <div id="Demo2" class="w3-hide w3-container">
            <p>Some other text..</p>
          </div>

        </div>      
      </div>

      <br>

     
      
     
    
    <!-- End Left Column -->
    </div>
    
       <!-- Middle Column -->
       <div class="w3-col m7">
    
<p>courses</p>
 

        <div class="right-side"><div class="nav">
        <script src="web/nav.js"></script>
     
        <button class="tablink" onclick="openPage('Videos', this, '#0c9992')">Videos</button>
<button class="tablink" onclick="openPage('PDFs', this, '#0c9992')" id="defaultOpen">PDFs</button>
<button class="tablink" onclick="openPage('Description', this, '#0c9992')">Description</button>
            
        </div>
        <div class="profile-body">
        <div id="Videos" class="tabcontent">
  <h3>Upload a new video</h3>
  <h1>Videos</h1>

<video autoplay id="video" controls>
    <source id="source" type="video/mp4">
</video>

<script>
    function selectedVideo(self){
        var file = self.files[0];
        var reader = new FileReader();

        reader.onload = function(e){
            var src = e.target.result;
            var video = document.getElementById("video");
            var source = document.getElementById("source");

            source.setAttribute("src",src);
            video.load();
            video.play();
        }
    }
</script>
</div>

<div id="PDFs" class="tabcontent">

   <h2>Upload a new PDF</h2>
                <Form Name="uploadpdf" Method="" Action="">
                    <Input Type="File" accept=".pdf">
</Form>
</div>

<div id="Description" class="tabcontent">
 
   <h1>Course Description</h1>
                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Hic exercitationem temporibus quisquam illum iure aliquid recusandae labore alias, veniam maiores assumenda rem mollitia modi eius tempore officiis esse eum cum. Odit tempore quidem, illum recusandae quasi harum earum architecto dicta voluptatum optio ab quod? Voluptas minima ratione dicta voluptatibus quam natus ipsam earum architecto, accusamus necessitatibus quod eligendi nobis odit nulla repellendus vero nemo provident rem adipisci magni laudantium sapiente.</p>

<script>
function openPage(pageName,elmnt,color) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].style.backgroundColor = "";
  }
  document.getElementById(pageName).style.display = "block";
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>
   
            
        </div>
    </div>
</div>

  <!-- End Middle Column -->
  
  </div>
  

    <br>
    
   
    
  <!-- End Right Column -->
  </div>
  
<!-- End Grid -->
</div>

<!-- End Page Container -->
</div>
<br>

<!-- Footer -->
<footer class="w3-container w3-theme-d3 w3-padding-16">
<h5></h5>
</footer>

<footer class="w3-container w3-theme-d5">
<p></p>
</footer>

<script>
// Accordion
function myFunction(id) {
var x = document.getElementById(id);
if (x.className.indexOf("w3-show") == -1) {
  x.className += " w3-show";
  x.previousElementSibling.className += " w3-theme-d1";
} else { 
  x.className = x.className.replace("w3-show", "");
  x.previousElementSibling.className = 
  x.previousElementSibling.className.replace(" w3-theme-d1", "");
}
}

// Used to toggle the menu on smaller screens when clicking on the menu button
function openNav() {
var x = document.getElementById("navDemo");
if (x.className.indexOf("w3-show") == -1) {
  x.className += " w3-show";
} else { 
  x.className = x.className.replace(" w3-show", "");
}
}

</script>

</body>
</html> 
