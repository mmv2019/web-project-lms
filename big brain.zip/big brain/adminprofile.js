$(document).ready(function(){  
    function fetch_data()  
    {  
        $.ajax({  
            url:"selectcourse.php",  
            method:"POST",  
            success:function(data){  
        $('#live_data_courses').html(data);  
            }  
        });  
    }  
    fetch_data();  
    $(document).on('click', '#btn_addcourse', function(){  
        var coursename = $('#coursename').text();  
        var price = $('#price').text();
        var instructor = $('#instructor').text();  
        var description = $('#description').text();
        if(coursename == '')  
        {  
            alert("Enter Course Name");  
            return false;  
        }  
        if(price == '')  
        {  
            alert("Enter Price");  
            return false;  
        }  
        if(instructor == '')  
        {  
            alert("Enter Instructor Name");  
            return false;  
        }  
         
        $.ajax({  
            url:"insertcourse.php",  
            method:"POST",  
            data:{coursename:coursename, price:price, instructor:instructor, description:description},  
            dataType:"text",  
            success:function(data)  
            {  
                alert(data);  
                fetch_data();  
            }  
        })  
    });  
    
  function edit_data(id, text, column_name)
    {
        $.ajax({
            url:"edit.php",
            method:"POST",
            data:{id:id, text:text, column_name:column_name},
            dataType:"text",
            success:function(data){
                //alert(data);
        $('#result').html("<div class='alert alert-success'>"+data+"</div>");
            }
        });
    }

    $(document).on('blur', '.coursename', function(){  
        var id = $(this).data("id1");  
        var coursename = $(this).text();  
        edit_data(id, coursename, "coursename");  
    });  
    $(document).on('blur', '.price', function(){  
        var id = $(this).data("id2");  
        var price = $(this).text();  
        edit_data(id,price, "price");  
    }); 
    $(document).on('blur', '.instructor', function(){  
        var id = $(this).data("id1");  
        var instructor = $(this).text();  
        edit_data(id, instructor, "instructor");  
    });  
    $(document).on('blur', '.description', function(){  
        var id = $(this).data("id2");  
        var description = $(this).text();  
        edit_data(id,description, "description");  
    }); 

    
    $(document).on('click', '.btn_deletecourse', function(){
        var id=$(this).data("id3");
        if(confirm("Are you sure you want to delete this?"))
        {
            $.ajax({
                url:"deletecourse.php",
                method:"POST",
                data:{id:id},
                dataType:"text",
                success:function(data){
                    alert(data);
                    fetch_data();
                }
            });
        }
    });

    $(document).on('click', '#edit_btn', function () {
        var id=$(this).data("id4");
        var coursename= $('#coursename'+id).text();
        var price= $('#price'+id).text();
        var instructor= $('#instructor'+id).text();
        var description= $('#description'+id).text();

        if(confirm("Are you sure you want to edit this?"))
        {
            $.ajax({
                url:"edit.php",
                method:"POST",
                data:{id:id,coursename:coursename,price:price,instructor:instructor,description:description},
                dataType:"text",
                success:function(data){
                    alert(data);
                    fetch_data();
                }
            });
        }
    });
}); 

  $(document).ready(function(){  
    function fetch_data()  
    {  
        $.ajax({  
            url:"selectadmin.php",  
            method:"POST",  
            success:function(data){  
        $('#live_data').html(data);  
            }  
        });  
    }  
    fetch_data();  
    $(document).on('click', '#btn_add', function(){  
        var name = $('#name').text();  
        var email = $('#email').text();  
        if(name == '')  
        {  
            alert("Enter Name");  
            return false;  
        }  
        if(email == '')  
        {  
            alert("Enter Email");  
            return false;  
        }  
        $.ajax({  
            url:"insertadmin.php",  
            method:"POST",  
            data:{name:name, email:email},  
            dataType:"text",  
            success:function(data)  
            {  
                alert(data);  
                fetch_data();  
            }  
        })  
    });  
/*    
  function edit_data(id, text, column_name)  
    {  
        $.ajax({  
            url:"edit.php",  
            method:"POST",  
            data:{id:id, text:text, column_name:column_name},  
            dataType:"text",  
            success:function(data){  
                //alert(data);
        $('#result').html("<div class='alert alert-success'>"+data+"</div>");
            }  
        });  
    }

    $(document).on('blur', '.Name', function(){  
        var id = $(this).data("id1");  
        var Name = $(this).text();  
        edit_data(id, Name, "Name");  
    });  
    $(document).on('blur', '.Email', function(){  
        var id = $(this).data("id2");  
        var Email = $(this).text();  
        edit_data(id,Email, "Email");  
    });  
    */
    $(document).on('click', '.btn_delete', function(){  
        var id=$(this).data("id3");  
        if(confirm("Are you sure you want to delete this?"))  
        {  
            $.ajax({  
                url:"deleteadmin.php",  
                method:"POST",  
                data:{id:id},  
                dataType:"text",  
                success:function(data){  
                    alert(data);  
                    fetch_data();  
                }  
            });  
        }  
    });  
});