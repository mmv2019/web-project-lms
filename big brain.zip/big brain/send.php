<!DOCTYPE html>
<html>
<title> send to HR</title>
<meta charset="UTF-8"><link rel="shortcut icon" type="image/png" href="logo1.png">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-teal.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans'>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/themes/smoothness/jquery-ui.min.css" />
<link rel="stylesheet" href="fontawesome/css/all.css">
        <link rel="stylesheet" href="fontawesome/css/all.min.css">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <body >


    
 <head>
    
      <style>
          html, body, h1, h2, h3, h4, h5 {font-family: "Open Sans", sans-serif}
          body{
            background: #ffffff;
            overflow-x: hidden;
            padding-top: 20px;
            font-family: "poppins",sans-serif;
    
         }
      form
     {
        width:100%;
        z-index: -1;
        text-align: center;
        font-family: "poppins",sans-serif;
      }
        .textt
        {
            padding:30px;
            background: #008080;
            width:60%;
         border-radius: 5px;
            margin:5px 2px;
            color:#fff;
            font-size: 1.5rem;
        }
        .text
        {
         background: #008080;
         padding:15px;
          width: 40%;
          border-radius: 5px;
         margin:5px 2px;
         color:#ffffff;
         font-size: 1.5rem;
         
         }
    .box select
                 {      
                    border: 0;
                    padding:10px;
                    width:25%;
                    border-radius: 5px;
                    background: #008080;
                    font-family:"Bree serif",sans-serif;
                    font-size: 1.5rem;
                    margin:5px 2px;
                    cursor: pointer;
                    outline: none;
                    margin-bottom: 10px;
                    transition: background .3s ease-in-out;
                    box-shadow: 0px 5px 7px rgba(0,0,0,.2);
                    color:#000;
                   }

            .send{
                 border: 0;
                    padding:10px;
                    width:20%;
                    border-radius: 3px;
                    background: #008080;
                    font-family:"Bree serif",sans-serif;
                    font-size: 1rem;
                    margin:5px 2px;
                    cursor: pointer;
                    outline: none;
                    margin-bottom: 10px;
                    transition: background .3s ease-in-out;
                    box-shadow: 0px 5px 7px rgba(0,0,0,.2);
                    color:#000;
                    font-size: 1.5rem;

            }

 . nav
            {
    width:100%;
    z-index: -1;
    
    }
    .navbar{
    color:#0c9992;
    }
.nav ul{
    display: flex;
    justify-content: center;
    list-style-type: none;
    height: 40px;
    background: #fff;
    box-shadow: 0px 2px 5px rgba(0,0,0,.3);
}
.nav ul li{
    padding:10px;
    width:100%;
    cursor: pointer;
    text-align: center;
    transition: all .2s ease-in-out;
}
.nav ul li.active,
.nav ul li:hover{
    box-shadow: 0px -3px 0px teal inset;
    color:wheat;
}

                   
         
   </style>
     <?php include('profileheader.php');?>


     <div class="profile-body">
            <div class="profile-posts ">
                 <br>
                 <form  class="form" name="myform" action="sendphp.php "  method="post" onsubmit="return vaildateform()" >
                    <h1>Message to HR</h1> <br>
                   <h4>User's Email  :</h4><input class="text" type="text"  id="mail" name="smail"     required> <br> 

                    <h4>The miss behaviour :</h4><input class="textt" type="text" name="reasonn"  required> 
                    <br>
                           <br>
                      <input   type="submit" class="send"  value="send" onclick="validatemail()"> 
                         <br> 
                    </form>
            </div>
        </div>
        </head>
            
    <script>
        function validatemail()
        {
            var m = document.getElementById("mail").value;
            if(m=='')
            {
                alert("wrong input please check your mail again !");
            }
            if (/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test(m))
            {
               
                alert("Sent seccufulyy !! "); 
                return (true)
            }
            else
            {
                 alert("wrong input please check your mail again !");    
            }
        }
    </script>
   
     </body>
        </html>