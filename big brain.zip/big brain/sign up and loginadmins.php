<?php include('header.php');
if(!isset($_GET['ut'])){
    header('Location:./user-type.php');
    exit;
}
?>
<html>
    <head>
        <title>Login and sign up form</title>
        <link rel="stylesheet" href="s.css">
        <?php 
        if(isset($_GET['error'])){
        ?>
        <script>alert("<?php echo $_GET['error'];?>")</script>
        <?php }
        ?>
    </head>
<body>
    <div class="hero">
        <div class="form-box">
            <div class="button-box">
                <div id="btn"></div>
                <button type="button" class="toggle-btn" onclick="login()">Log In</button>
                <button type="button" class="toggle-btn" onclick="signup()">Sign Up</button>
          </div>   
          <div class="icon">
               <img src='Logo1.png'>
           </div>
            
        <form id="login" class="input-group" action="mm.php" method="post">
            <input type="text" name='Email'class="input-field" placeholder="Email" required>
            <input type="password" name="pass" class="input-field" placeholder="Enter password" required><p><br></p>
            <input type="hidden" name="type" value="<?php echo $_GET['ut']?>">
            <input type="checkbox" class="check-box" > <span>Remember Password </span><p><br></p>
            <button type="submit" name="Submit" class="submit-btn" >Log in</button>        
        </form>
       <form id="signup" class="input-group" action="" method="">
           <br>
           <p> Please contact us:</p><br>
               <p>Email: bigbrain_admin@gmail.com</p><br>
            <p>   Hotline:190000</p>
            </form>
        </div>
    </div>
    <script>
        var x=document.getElementById("login");
        var y=document.getElementById("signup");
        var z=document.getElementById("btn");

        function signup(){
            x.style.left='-400px';
            y.style.left='50px';
            z.style.left='110px';
        }

        function login(){
          x.style.left='50px';
           y.style.left='450px';
            z.style.left='0px';
       <?php echo'hello' ?>
        }
       
       


    </script>
</body>
</html>