<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bigbrain";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
//Get latest notifications
$object = new stdClass();
if(isset($_POST['email']) && isset($_POST['last_notification_id'])){
    $query = "SELECT * FROM warnings WHERE email='{$_POST['email']}' AND id>'{$_POST['last_notification_id']}'";
    $result = mysqli_query($conn,$query);
    if($row=mysqli_fetch_assoc($result)){
        $object->description = $row['description'];
        $object->type = $row['type'];
        $object->id = $row['id'];
        $object->lid = $_POST['last_notification_id'];
    }else{
        $object->empty = true;
    }
    echo json_encode($object);
}else{
    echo "error";
}

?>