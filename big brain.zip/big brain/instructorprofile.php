<?php
session_start();
 if($_SESSION['ut']!='in'){
  header('Location:./user-type.php');
  exit;
}
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bigbrain";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);


$email=$_SESSION['email'];
$name=$_SESSION['name'];
$no=$_SESSION['phoneno'];
$img=$_SESSION['image'];
$datejoined=$_SESSION['datejoined'];
//$query = "SELECT id FROM warnings ORDER BY id DESC LIMIT 1";
//$result = mysqli_query($conn, $query);
//$row = mysqli_fetch_assoc($result);
//$last_notification = $row['id'];

//$notifications_query = "SELECT * FROM warnings WHERE email='{$email}' ORDER BY id DESC LIMIT 5";
//$notifications = mysqli_query($conn, $notifications_query);

?>
<html>
<title> Instructor</title>
<meta charset="UTF-8"><link rel="shortcut icon" type="image/png" href="logo1.png">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-teal.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans'>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/themes/smoothness/jquery-ui.min.css" />
<link rel="stylesheet" href="fontawesome/css/all.css">
        <link href="styles.css" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="fontawesome/css/all.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
html, body, h1, h2, h3, h4, h5 {font-family: "Open Sans", sans-serif}

.nav{
    width:100%;
    
}
.w3-top{
    z-index: 999;
}
.navbar{
    color:#0c9992;
}
.nav ul{
    display: flex;
    justify-content: center;
    list-style-type: none;
    height: 40px;
    background: #fff;
    box-shadow: 0px 2px 5px rgba(0,0,0,.3);
}
.nav ul li{
    padding:10px;
    width:100%;
    cursor: pointer;
    text-align: center;
    transition: all .2s ease-in-out;
}
.nav ul li.active,
.nav ul li:hover{
    box-shadow: 0px -3px 0px teal inset;
    color:wheat;
}

</style>
<body class="w3-theme-14">

<!-- Navbar -->
<div class="w3-top">
 <div class="w3-bar w3-theme-d2 w3-left-align w3-large">
  <a class="w3-bar-item w3-button w3-hide-medium w3-hide-large w3-right w3-padding-large w3-large w3-theme-teal" href="javascript:void(0);" onclick="openNav()"><i class="fa fa-bars"></i></a>
  <a href="homee.php" class="w3-bar-item w3-button w3-padding-large w3-hover-red"><i class="fa fa-home w3-margin-right"></i>BIG BRAIN</a>
  <a href="account settings.php" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-red" title="Account Settings"><i class="fas fa-user-cog"></i></a>
  <a href="chat/index.php" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-red" title="Messages"><i class="fas fa-comment-dots"></i></a>
  <div class="w3-dropdown-hover w3-hide-small w3-hover-red">
  <!--  <button class="w3-button w3-padding-large w3-hover-red" title="Notifications"><i class="fa fa-bell"></i><span class="w3-badge w3-right w3-small w3-green" id="notification-counter"><?php //echo mysqli_num_rows($notifications);?></span></button>     
    <div data-id="<?php // echo $last_notification; ?>" data-email="<?php // echo $email;?>" id="notification-container" class="w3-dropdown-content w3-card-4 w3-bar-block " style="width:300px">
      <?php
       // while($row = mysqli_fetch_assoc($notifications)){
            
            ?>
      <div  class="w3-bar-item w3-button"><?php //echo $row['description'];?></div>
            
            <?php
      //  }
      ?>
    </div> -->
  </div>
  <a href="sign out.php" class="w3-bar-item w3-button w3-hide-small w3-right w3-padding-large " title="sign out"><i class="fas fa-sign-out-alt"></i></a>



  <a href="#" class="w3-bar-item w3-button w3-hide-small w3-right w3-padding-large "  title="My Account">
    <img src="<?php echo $img; ?>"  class="w3-circle" style="height:23px;width:23px" alt="Avatar">
  </a>
 </div>
</div>

<!-- Navbar on small screens -->
<div id="navDemo" class="w3-bar-block w3-theme-d2 w3-hide w3-hide-large w3-hide-medium w3-large">
  <a href="#" class="w3-bar-item w3-button w3-padding-large">Link 1</a>
  <a href="#" class="w3-bar-item w3-button w3-padding-large">Link 2</a>
  <a href="#" class="w3-bar-item w3-button w3-padding-large">Link 3</a>
  <a href="#" class="w3-bar-item w3-button w3-padding-large">My Profile</a>
</div>

<!-- Page Container -->
<div class="w3-container w3-content" style="max-width:1400px;margin-top:80px">    
  <!-- The Grid -->
  <div class="w3-row">
    <!-- Left Column -->
    <div class="w3-col m3">
      <!-- Profile -->
      <div class="w3-card w3-round w3-white">
        <div class="w3-container">
         <h4 class="w3-center">Instructor Profile</h4>
         <p class="w3-center"><img src="<?php echo $img; ?>" class="w3-circle" style="height:106px;width:106px" alt="Avatar"></p>
         <hr>
         <p><i class="fa fa-pencil fa-fw w3-margin-right w3-text-theme"></i><?php echo $name?></p>
         <p><i class="fas fa-at fa-fw w3-margin-right w3-text-theme"></i> <?php echo $email?></p>
         <p><i class="far fa-clock fa-fw w3-margin-right w3-text-theme"></i> <?php echo $datejoined?></p>
        </div>
      </div>
      <br>
      
      <!-- Accordion -->
      <div class="w3-card w3-round w3-theme-d1">
        <div class="w3-theme">
          <button onclick="myFunctionn()" class="w3-button w3-block w3-theme-d1 w3-left-align"><i class="fa fa-circle-o-notch fa-fw w3-margin-right"></i>Add Courses</button>
          <div id="Demo1" class="w3-hide w3-container">
        <p>courses</p>
          </div>
          <button onclick="myFunction('Demo2')" class="w3-button w3-block w3-theme-d1 w3-left-align"><i class="fas fa-sticky-note w3-margin-right"></i> Notes</button>
          <div id="Demo2" class="w3-hide w3-container">
            <p>Some other text..</p>
          </div>

        </div>      
      </div>
      <br>

     
      
     
    
    <!-- End Left Column -->
    </div>
    
       <!-- Middle Column -->
       <div class="w3-col m7">
       <div class="col-lg-9 col-md-push-3">
       <p>-------------------------------------</p>
 </div>
  
<!-- End Grid -->
</div>

<!-- End Page Container -->
</div>
<br>

<!-- Footer -->
<footer class="w3-container w3-theme-d3 w3-padding-16">
<h5></h5>
</footer>

<footer class="w3-container w3-theme-d5">
<p></p>
</footer>

<script>
// Accordion
function myFunction(id) {
var x = document.getElementById(id);
if (x.className.indexOf("w3-show") == -1) {
  x.className += " w3-show";
  x.previousElementSibling.className += " w3-theme-d1";
} else { 
  x.className = x.className.replace("w3-show", "");
  x.previousElementSibling.className = 
  x.previousElementSibling.className.replace(" w3-theme-d1", "");
}
}
function myFunctionn()
{
  window.location.href="http://localhost/big%20brain/addcourse.php";
}
// Used to toggle the menu on smaller screens when clicking on the menu button
function openNav() {
var x = document.getElementById("navDemo");
if (x.className.indexOf("w3-show") == -1) {
  x.className += " w3-show";
} else { 
  x.className = x.className.replace(" w3-show", "");
}
}
</script>
<script>
var notification_container = document.getElementById('notification-container');
function getNotifications(){
    var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange = function() {
   
    if (this.readyState == 4) {
        console.log(this.responseText);
    var response = JSON.parse(this.responseText);
      if(this.status == 200){
        if(!response['empty']){
            var description = response['description'];
            var type = response['type'];
            var n_id = response['id'];
            var notificationElement = document.createElement('div'); 
            notificationElement.classList.add('w3-button');
            notificationElement.classList.add('w3-bar-item');
            // notificationElement.setAttribute('href',"page");
            notificationElement.innerHTML = description;
            notification_container.appendChild(notificationElement);
            notification_container.setAttribute('data-id',n_id);
            document.getElementById('notification-counter').innerHTML = parseInt(document.getElementById('notification-counter').innerHTML)+1;
      }
      }
    }
};
var params = "email="+notification_container.getAttribute('data-email')+"&last_notification_id="+notification_container.getAttribute('data-id');
xhttp.open("POST", "functions/getNotifications.php", true);
xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
xhttp.send(params);
}
setInterval(function(){
    getNotifications();
},5000);

</script>
</body>
</html> 
