-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 27, 2021 at 06:50 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bigbrain`
--

-- --------------------------------------------------------

--
-- Table structure for table `allquestions`
--

CREATE TABLE `allquestions` (
  `id` int(11) NOT NULL,
  `question` text NOT NULL,
  `answer` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `allquestions`
--

INSERT INTO `allquestions` (`id`, `question`, `answer`) VALUES
(1, 'how can i change my profile pic?', ''),
(2, 'Can i have a membership?', '');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `course_id`, `student_id`) VALUES
(6, 39, 18),
(7, 38, 18),
(8, 31, 18),
(9, 32, 18),
(10, 39, 18);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `ID` int(11) NOT NULL,
  `name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`ID`, `name`) VALUES
(1, 'business'),
(2, 'language learning'),
(3, 'computer science'),
(4, 'arts & humanities');

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

CREATE TABLE `chat` (
  `to` varchar(32) NOT NULL,
  `from` varchar(32) NOT NULL,
  `msg` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `chat`
--

INSERT INTO `chat` (`to`, `from`, `msg`) VALUES
('magedmaryam2@gmail.com', 'ashraf@gmail.com', 'hi'),
('magedmaryam2@gmail.com', 'ahmed@gmail.com', 'bye');

-- --------------------------------------------------------

--
-- Table structure for table `chat_message`
--

CREATE TABLE `chat_message` (
  `chat_message_id` int(11) NOT NULL,
  `to_user_id` int(11) NOT NULL,
  `from_user_id` int(11) NOT NULL,
  `chat_message` text NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chat_message`
--

INSERT INTO `chat_message` (`chat_message_id`, `to_user_id`, `from_user_id`, `chat_message`, `timestamp`, `status`) VALUES
(0, 1, 2, 'hi', '2021-02-24 18:24:39', 0),
(0, 2, 1, 'hiii\n\n', '2021-02-24 18:25:21', 0),
(0, 1, 2, 'bye', '2021-02-24 18:25:27', 0),
(0, 0, 1, '<p><img src=\"uploads/bg.jpg\" class=\"img-thumbnail\" width=\"200\" height=\"160\"></p><br>', '2021-02-25 20:05:34', 1),
(0, 2, 1, '?', '2021-02-25 20:05:49', 1),
(0, 2, 1, 'bye', '2021-02-25 22:16:35', 1),
(0, 0, 1, 'hiiiiiiii', '2021-02-25 22:16:48', 1),
(0, 0, 3, '<p><img src=\"uploads/Logo1.png\" class=\"img-thumbnail\" width=\"200\" height=\"160\"></p><br>', '2021-02-26 22:38:09', 1),
(0, 0, 3, '<p><img src=\"uploads/spanish.png\" class=\"img-thumbnail\" width=\"200\" height=\"160\"></p><br>', '2021-02-26 22:38:39', 1),
(0, 0, 3, '<p><img src=\"../uploads/design.png\" class=\"img-thumbnail\" width=\"200\" height=\"160\"></p><br>', '2021-02-26 22:39:16', 1);

-- --------------------------------------------------------

--
-- Table structure for table `chat_messages`
--

CREATE TABLE `chat_messages` (
  `chat_message_id` int(11) NOT NULL,
  `to_user_id` int(11) NOT NULL,
  `from_user_id` int(11) NOT NULL,
  `chat_message` text CHARACTER SET latin1 NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `chat_messages`
--

INSERT INTO `chat_messages` (`chat_message_id`, `to_user_id`, `from_user_id`, `chat_message`, `timestamp`, `status`) VALUES
(1, 2, 1, 'jaja\n\n', '2021-02-24 17:03:41', 0),
(2, 1, 2, 'baba', '2021-02-24 17:21:36', 0);

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `name` varchar(50) NOT NULL,
  `category` varchar(250) NOT NULL,
  `img` text NOT NULL,
  `price` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `instructor` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL,
  `video` text NOT NULL,
  `pdf` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`name`, `category`, `img`, `price`, `id`, `instructor`, `description`, `video`, `pdf`) VALUES
('nada', '', 'courses/1614340583-49d8eeebdbd750b477d934d8f2cbc278.jpg', 5, 35, 'aya', 'jhfd', '', ''),
('ragaa', '', 'courses/1614340583-49d8eeebdbd750b477d934d8f2cbc278.jpg', 5, 37, 'aya', 'jhfd', 'courses/1614340517-Task2.mp4', 'courses/1614340517-Doc1.docx'),
('test 2', '', 'courses/1614340583-49d8eeebdbd750b477d934d8f2cbc278.jpg', 5, 38, 'aya', 'jhfd', 'courses/1614340542-Task2.mp4', 'courses/1614340542-Doc1.docx'),
('Test', 'business', 'courses/1614392547-1614340488-49d8eeebdbd750b477d934d8f2cbc278.jpg', 2500, 40, 'Mariam Maged', 'Test', 'courses/1614391520-1614340488-Task2.mp4', 'courses/1614391520-Push-Down Automata_Added_Presentation.pdf'),
('a', 'business', 'courses/1614392072-1614340488-49d8eeebdbd750b477d934d8f2cbc278.jpg', 55, 41, 'Mariam Maged', 'test', 'courses/1614392072-1614340488-Task2.mp4', 'courses/1614392072-Summary.docx'),
('Test', 'business', 'courses/1614392547-1614340488-49d8eeebdbd750b477d934d8f2cbc278.jpg', 55, 42, 'Mariam Maged', 'Test', 'courses/1614392316-1614340488-Task2.mp4', 'courses/1614392316-Summary.docx'),
('Testtt', 'language learning', 'courses/1614392380-1614340488-49d8eeebdbd750b477d934d8f2cbc278.jpg', 0, 43, 'Mariam Maged', 'Test', 'courses/1614392380-1614340488-Task2.mp4', 'courses/1614392380-Summary.docx'),
('aaaa', 'business', 'courses/1614392547-1614340488-49d8eeebdbd750b477d934d8f2cbc278.jpg', 3000, 44, 'Mariam Maged', 'HELLO world', 'courses/1614392547-1614340488-Task2.mp4', 'courses/1614392547-Desc.docx'),
('q', '', '', 0, 46, 'q', 'q', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `name` varchar(20) NOT NULL,
  `email` varchar(32) NOT NULL,
  `phoneno` varchar(15) NOT NULL,
  `password` varchar(255) NOT NULL,
  `ut` varchar(2) NOT NULL,
  `img` varchar(250) NOT NULL,
  `course-code` varchar(10) NOT NULL,
  `has-warning` tinyint(1) NOT NULL,
  `datejoined` varchar(32) NOT NULL,
  `id` int(11) NOT NULL,
  `warning` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`name`, `email`, `phoneno`, `password`, `ut`, `img`, `course-code`, `has-warning`, `datejoined`, `id`, `warning`) VALUES
('aya', 'aya123@gmail.com', '01156052920', '$2y$10$S/aaNa7lxq3uaUD.UyI2DeJVj8.W1folcQa8HCFDXookfzG9BIlVW', 'hr', 'uploads/1614340156-49d8eeebdbd750b477d934d8f2cbc278.jpg', '', 0, '', 1, ''),
('maryam', 'maryam2@gmail.com', '1220733507', '$2y$10$oiawG6sUGY8BSrtrbNLez.4Y4TcE8i8a6ZsKyiAbpg1W.zdD6Sur6', 'in', '	\r\nimg/profile.png', '', 0, '23-02-2021', 2, ''),
('sarax', 'sara@gmail.com', '1220733508', '$2y$10$oiawG6sUGY8BSrtrbNLez.4Y4TcE8i8a6ZsKyiAbpg1W.zdD6Sur6', 'au', '	\r\nimg/profile.png', '', 0, '23-02-2021', 3, ''),
('ragaa', 'ragaamostafa@gmail.com', '1000022781', '$2y$10$oiawG6sUGY8BSrtrbNLez.4Y4TcE8i8a6ZsKyiAbpg1W.zdD6Sur6', 'ad', 'uploads/1614291807-72069203_428759254711928_4949509152738883578_nlow.jpg', '', 0, '', 11, ''),
('Mariam Maged', 'magedmaryam2@gmail.com', '1000022781', '$2y$10$KggUtcZozUiE8PqgynvAhuTrXFMs1oCTLFaAsNGTCzUT8OVE3ppo.', 'st', 'img/profile.png', '', 0, '2021-02-25', 17, ''),
('ahmed ', 'ahmed22@gmail.com', '1000022781', '$2y$10$oiawG6sUGY8BSrtrbNLez.4Y4TcE8i8a6ZsKyiAbpg1W.zdD6Sur6', 'st', 'img/profile.png', '', 0, '2021-02-25', 18, ''),
('yasmina', 'yasmina20@gmail.com', '1000022781', '$2y$10$zORfVeEXuzIWMSRYULd0sO4RsSF1xgxUOI9Ls8TJAe3ztLakCYjpC', 'in', 'img/profile.png', '', 0, '2021-02-25', 19, ''),
('Mariam Maged', 'magedmaryam2000@gmail.com', '-01000022781', '$2y$10$601/1lNpdnU4iQHNDwe1IeDnsOC7XDttyhNCKDy6DRhQkSwEyj03i', 'ad', 'img/profile.png', '', 0, '2021-02-27', 21, '');

-- --------------------------------------------------------

--
-- Table structure for table `enrolled`
--

CREATE TABLE `enrolled` (
  `course name` varchar(50) NOT NULL,
  `pdf` text NOT NULL,
  `video` text NOT NULL,
  `img` text NOT NULL,
  `student_id` int(11) NOT NULL,
  `instructor` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL,
  `category` varchar(2) NOT NULL,
  `cid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `enrolled`
--

INSERT INTO `enrolled` (`course name`, `pdf`, `video`, `img`, `student_id`, `instructor`, `description`, `category`, `cid`) VALUES
('OOP', '', 'courses\\Task2.mp4', 'uploads/security.png', 1, 'Maryam', 'java101', 'cs', 2),
('Spanish', 'courses/1614340488-Doc1.docx', 'courses\\Task2.mp4', 'uploads/spanish.png', 1, 'Ragaa', 'speak spanish now', 'cs', 3),
('graphic design', '', '', 'uploads/design.png', 1, 'Sandy', '', '', 4);

-- --------------------------------------------------------

--
-- Table structure for table `frequently`
--

CREATE TABLE `frequently` (
  `id` int(11) NOT NULL,
  `question` text NOT NULL,
  `answer` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `frequently`
--

INSERT INTO `frequently` (`id`, `question`, `answer`) VALUES
(2, 'how can i change my profile pic?', 'from account settings'),
(3, 'can I have a membership', 'yes of course; but first send an email'),
(32, 'can i download the course material?', 'yes you can once you enrolled in it!');

-- --------------------------------------------------------

--
-- Table structure for table `login_details`
--

CREATE TABLE `login_details` (
  `login_details_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `last_activity` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_type` enum('no','yes') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_details`
--

INSERT INTO `login_details` (`login_details_id`, `user_id`, `last_activity`, `is_type`) VALUES
(0, 0, '2021-02-26 23:09:58', 'no'),
(0, 0, '2021-02-26 23:09:58', 'no'),
(0, 0, '2021-02-26 23:09:58', 'no'),
(0, 0, '2021-02-26 23:09:58', 'no'),
(0, 0, '2021-02-26 23:09:58', 'no'),
(0, 0, '2021-02-26 23:09:58', 'no'),
(0, 0, '2021-02-26 23:09:58', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `miisbehave`
--

CREATE TABLE `miisbehave` (
  `id` int(11) NOT NULL,
  `AdminEmail` varchar(32) NOT NULL,
  `reason` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `miisbehave`
--

INSERT INTO `miisbehave` (`id`, `AdminEmail`, `reason`) VALUES
(1, 'ragaamostafa@gmail.com', 'insulted an instructor');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `desc` text NOT NULL,
  `price` decimal(7,2) NOT NULL,
  `rrp` decimal(7,2) NOT NULL DEFAULT 0.00,
  `quantity` int(11) NOT NULL,
  `img` text NOT NULL,
  `date_added` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `desc`, `price`, `rrp`, `quantity`, `img`, `date_added`) VALUES
(1, 'Smart Watch', '<p>Unique watch made with stainless steel, ideal for those that prefer interative watches.</p>\r\n<h3>Features</h3>\r\n<ul>\r\n<li>Powered by Android with built-in apps.</li>\r\n<li>Adjustable to fit most.</li>\r\n<li>Long battery life, continuous wear for up to 2 days.</li>\r\n<li>Lightweight design, comfort on your wrist.</li>\r\n</ul>', '29.99', '0.00', 10, 'watch.jpg', '2019-03-13 17:55:22'),
(2, 'Wallet', '', '14.99', '19.99', 34, 'wallet.jpg', '2019-03-13 18:52:49'),
(3, 'Headphones', '', '19.99', '0.00', 23, 'headphones.jpg', '2019-03-13 18:47:56'),
(4, 'Digital Camera', '', '69.99', '0.00', 7, 'camera.jpg', '2019-03-13 17:42:04');

-- --------------------------------------------------------

--
-- Table structure for table `q&a`
--

CREATE TABLE `q&a` (
  `questions` text NOT NULL,
  `answer` text NOT NULL,
  `view` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `survay`
--

CREATE TABLE `survay` (
  `id` int(11) NOT NULL,
  `q1` text NOT NULL,
  `q2` text NOT NULL,
  `q3` text NOT NULL,
  `q4` text NOT NULL,
  `q5` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `feedback` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `survay`
--

INSERT INTO `survay` (`id`, `q1`, `q2`, `q3`, `q4`, `q5`, `user_id`, `feedback`) VALUES
(7, 'sometimes', 'Frequently', 'sometimes', 'neutral', 'Frequently', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `survey`
--

CREATE TABLE `survey` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `survey_answers`
--

CREATE TABLE `survey_answers` (
  `id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `answer` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `survey_questions`
--

CREATE TABLE `survey_questions` (
  `id` int(11) NOT NULL,
  `survey_id` int(11) NOT NULL,
  `question` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tblsurvey`
--

CREATE TABLE `tblsurvey` (
  `ID` int(11) NOT NULL,
  `Question` text NOT NULL,
  `QuestionA` varchar(255) NOT NULL,
  `QuestionB` varchar(255) NOT NULL,
  `QuestionC` varchar(255) NOT NULL,
  `VotedA` int(11) NOT NULL,
  `VotedB` int(11) NOT NULL,
  `VotedC` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `usertype`
--

CREATE TABLE `usertype` (
  `id` int(10) NOT NULL,
  `name` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `usertype`
--

INSERT INTO `usertype` (`id`, `name`) VALUES
(1, 'student'),
(2, 'instructor'),
(3, 'admin'),
(4, 'auditor'),
(5, 'hr');

-- --------------------------------------------------------

--
-- Table structure for table `warnings`
--

CREATE TABLE `warnings` (
  `email_ad` varchar(32) NOT NULL,
  `name_ad` varchar(32) NOT NULL,
  `warning` tinyint(1) NOT NULL,
  `warningreason` text NOT NULL,
  `admins_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `warnings`
--

INSERT INTO `warnings` (`email_ad`, `name_ad`, `warning`, `warningreason`, `admins_id`) VALUES
('mmv@gmail.com', 'mmv', 1, 'reason', 0),
('mmv@gmail.com', 'mmv', 1, 'reason', 0),
('mmv@gmail.com', 'mmv', 1, 'reason', 0),
('mmv@gmail.com', 'mmv', 1, 'reason', 0),
('mmv@gmail.com', 'mmv', 1, 'reason', 0),
('mmv@gmail.com', 'mmv', 1, 'reason', 0),
('mmv@gmail.com', 'mmv', 1, 'reason', 0),
('mmv@gmail.com', 'mmv', 1, 'reason', 0),
('mmv@gmail.com', 'mmv', 1, 'reason', 0),
('mmv@gmail.com', 'mmv', 1, 'reason', 0),
('mmv@gmail.com', 'mmv', 1, 'reason', 0),
('mmv@gmail.com', 'mmv', 1, 'reason', 0),
('mmv@gmail.com', 'mmv', 1, 'reason', 0),
('mmv@gmail.com', 'mmv', 1, 'reason', 0),
('mmv@gmail.com', 'mmv', 1, 'reason', 0),
('mmv@gmail.com', 'mmv', 1, 'reason', 0),
('mmv@gmail.com', 'mmvc', 1, 'reason', 0),
('mmv@gmail.com', 'mmvc', 1, 'reason', 0),
('mmv@gmail.com', 'mmv', 1, 'reason', 0),
('mmv@gmail.com', 'mmv', 1, 'reason', 0),
('mmv@gmail.com', 'mmv', 1, 'reason', 0),
('mmv@gmail.com', 'mmv', 1, 'reason', 0),
('mmv@gmail.com', 'mmv', 1, 'reason', 0),
('mmv@gmail.com', 'mmv', 1, 'reason', 0),
('mmv@gmail.com', 'mmv', 1, 'reason', 0),
('mmv@gmail.com', 'mmv', 1, 'reason', 0),
('', '', 1, 'reason', 0),
('', '', 1, 'reason', 0),
('', '', 1, 'reason', 0),
('', '', 1, 'reason', 0),
('', '', 1, '', 0),
('', '', 1, '', 0),
('', '', 1, '', 0),
('', '', 1, '', 0),
('', '', 1, '', 0),
('', '', 1, '', 0),
('', '', 1, '', 0),
('', '', 1, '', 0),
('', '', 1, '', 0),
('', '', 1, '', 0),
('', '', 1, '', 0),
('', '', 1, '', 0),
('', '', 1, '', 0),
('', '', 1, '', 0),
('mmv@gmail.com', 'mmv', 1, 'sdaf', 0),
('mmv@gmail.com', 'mmv', 1, 'sdaf', 0),
('mmv@gmail.com', 'mmv', 1, '', 0),
('mmv@gmail.com', 'mmv', 1, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `warning_types`
--

CREATE TABLE `warning_types` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `warning_types`
--

INSERT INTO `warning_types` (`id`, `name`) VALUES
(1, 'test');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `allquestions`
--
ALTER TABLE `allquestions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD PRIMARY KEY (`chat_message_id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `enrolled`
--
ALTER TABLE `enrolled`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `frequently`
--
ALTER TABLE `frequently`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `miisbehave`
--
ALTER TABLE `miisbehave`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `survay`
--
ALTER TABLE `survay`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `survey`
--
ALTER TABLE `survey`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `survey_answers`
--
ALTER TABLE `survey_answers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `survey_questions`
--
ALTER TABLE `survey_questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblsurvey`
--
ALTER TABLE `tblsurvey`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `warning_types`
--
ALTER TABLE `warning_types`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `allquestions`
--
ALTER TABLE `allquestions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `chat_messages`
--
ALTER TABLE `chat_messages`
  MODIFY `chat_message_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `enrolled`
--
ALTER TABLE `enrolled`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `frequently`
--
ALTER TABLE `frequently`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `miisbehave`
--
ALTER TABLE `miisbehave`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `survay`
--
ALTER TABLE `survay`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `survey`
--
ALTER TABLE `survey`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `survey_answers`
--
ALTER TABLE `survey_answers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `survey_questions`
--
ALTER TABLE `survey_questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblsurvey`
--
ALTER TABLE `tblsurvey`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `warning_types`
--
ALTER TABLE `warning_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
