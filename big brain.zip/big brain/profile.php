<?php
session_start();
include 'db.php';

$img=$_SESSION['img'];
$Name=$_SESSION['name'];
$Email=$_SESSION['email'];
$datejoined=$_SESSION['datejoined'];
?>

<!DOCTYPE html>
<html>
<title></title><link rel="shortcut icon" type="image/png" href="logo1.png">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-teal.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans'>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<!-- CSS vertical tab -->
<link rel="stylesheet" href="vertical-tab-admin.css">

<!-- M3RFSH BTO3 EH DOL BS MARYAM HATAHOM -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/themes/smoothness/jquery-ui.min.css" />
<!--<link rel="stylesheet" href="fontawesome/css/all.css">
        <link rel="stylesheet" href="fontawesome/css/all.min.css"> -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- datejoined icon -->
<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>


<style>
html, body, h1, h2, h3, h4, h5 {font-family: "Open Sans", sans-serif}


</style>
<body class="w3-theme-14">

<!-- Navbar 
<div class="w3-top">
 <div class="w3-bar w3-theme-l3  w3-left-align w3-large">
  <a class="w3-bar-item w3-button w3-hide-medium w3-hide-large w3-right w3-padding-large w3-hover-white w3-large w3-theme-d2" href="javascript:void(0);" onclick="openNav()"><i class="fa fa-bars"></i></a>
  <a href="home.php" class="w3-bar-item w3-button w3-padding-large w3-theme-d4"><i class="fa fa-home w3-margin-right"></i>BigBrain</a>
  
  <a href="#" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white" title="Account Settings"><i class="fa fa-user"></i></a>
  <a href="#" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white" title="Messages"><i class="fa fa-envelope"></i></a>
  <div class="w3-dropdown-hover w3-hide-small">
    <button class="w3-button w3-padding-large" title="Notifications"><i class="fa fa-bell"></i><span class="w3-badge w3-right w3-small w3-green">3</span></button>     
    <div class="w3-dropdown-content w3-card-4 w3-bar-block" style="width:300px">
      <a href="#" class="w3-bar-item w3-button">student enrolled in a course</a>
      <a href="#" class="w3-bar-item w3-button">instructor added new course</a>
      <a href="#" class="w3-bar-item w3-button">student needs help</a>
    </div>
  </div>
  <a href='SignOut.php' style="float: right;">SignOut</a>
  <a href="#" class="w3-bar-item w3-button w3-hide-small w3-right w3-padding-large w3-hover-white" title="My Account">
    <img src="<?php // echo $_SESSION["img"]; ?>" class="w3-circle" style="height:23px;width:23px" alt="Avatar">
  </a>

 </div>
</div>
-->

<!-- Navbar -->
<div class="w3-top">
 <div class="w3-bar w3-theme-d2 w3-left-align w3-large">
  <a class="w3-bar-item w3-button w3-hide-medium w3-hide-large w3-right w3-padding-large w3-large w3-theme-teal" href="javascript:void(0);" onclick="openNav()"><i class="fa fa-bars"></i></a>
  <a href="home.php" class="w3-bar-item w3-button w3-padding-large w3-hover-white"><i class="fa fa-home w3-margin-right"></i>BigBrain</a>

  <a href="#" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white" title="Account Settings"><i class="fa fa-user"></i></a>
  <a href="#" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white" title="Messages"><i class="fa fa-envelope"></i></a>
  <div class="w3-dropdown-hover w3-hide-small w3-hover-white">
  <!--
    <button class="w3-button w3-padding-large w3-hover-white" title="Notifications"><i class="fa fa-bell"></i><span class="w3-badge w3-right w3-small w3-green">3</span></button>     
    <div class="w3-dropdown-content w3-card-4 w3-bar-block " style="width:300px">
      <a href="#" class="w3-bar-item w3-button">student enrolled in a course</a>
      <a href="#" class="w3-bar-item w3-button">instructor added new course</a>
      <a href="#" class="w3-bar-item w3-button">student needs help</a>
    </div>
    -->
  </div>
  <a href="SignOut.php" class="w3-bar-item w3-button w3-hide-small w3-right w3-padding-large " title="sign out"><i class="fas fa-sign-out-alt"></i></a>
  <a href="#" class="w3-bar-item w3-button w3-hide-small w3-right w3-padding-large w3-hover-white" title="My Account">
    <img src="<?php echo $img; ?>"  class="w3-circle" style="height:23px;width:23px" alt="Avatar">
  </a>
 </div>
</div>

<!-- Navbar on small screens -->
<div id="navDemo" class="w3-bar-block w3-theme-d2 w3-hide w3-hide-large w3-hide-medium w3-large">
  <a href="#" class="w3-bar-item w3-button w3-padding-large">Link 1</a>
  <a href="#" class="w3-bar-item w3-button w3-padding-large">Link 2</a>
  <a href="#" class="w3-bar-item w3-button w3-padding-large">Link 3</a>
  <a href="#" class="w3-bar-item w3-button w3-padding-large">My Profile</a>
</div>

<!-- Page Container -->
<div class="w3-container w3-content" style="max-width:1400px;margin-top:80px">    
  <!-- The Grid -->
  <div class="w3-row">
    <!-- Left Column -->
    <div class="w3-col m3">
      <!-- Profile -->
      <div class="w3-card w3-round w3-white">
        <div class="w3-container">
         <h4 class="w3-center">My Profile</h4>
         <p class="w3-center"><img src="<?php echo $img; ?>" class="w3-circle" style="height:106px;width:106px" alt="Avatar"></p>
         <hr>

         <p ><i class="fa fa-id-card fa-fw w3-margin-right w3-text-theme"></i> <?php echo $_SESSION["name"];?></p>
         <p><i class="fa fa-envelope fa-fw w3-margin-right w3-text-theme"></i> <?php echo $_SESSION["email"]; ?></p>
         <p><i class="fas fa-calendar fa-fw w3-margin-right w3-text-theme"></i> <?php echo $_SESSION["datejoined"]; ?></p>
        </div>
      </div>
      <br>
      
   <!-- Accordion -->
   <div class="w3-card w3-round w3-theme-d1 tab">
        <div class="w3-theme">
          <button onclick= "openTAB(event, 'admins')"   class=" tablinks w3-button w3-block w3-theme-d1 w3-left-align"><i class="fa fa-user-plus fa-fw w3-margin-right"></i>Admins</button>
          
          <button onclick= "openTAB(event, 'cc')" id="defaultOpen" class="tablinks w3-button w3-block w3-theme-d1 w3-left-align"><i class="fa fa-list-ul fa-fw w3-margin-right"></i> All Courses</button>
          
          <button onclick= "openTAB(event, 'students')"  class="tablinks w3-button w3-block w3-theme-d1 w3-left-align"><i class="fa fa-users fa-fw w3-margin-right"></i> All Students</button>
          
          </div>
        </div>      
      </div>
      <br>
     
    <!-- End Left Column -->
   <!-- </div> -->
    
   
    

        

   <!-- <div class="w3-col m7 " style="margin-left:25%; padding-top:0px;"> -->
    
       <?php
       // include 'viewandeditadmins.php';
      //include 'coursesforadmin.php';
       ?>
      
<div id="admins" class="tabcontent">
  <h3>Admins</h3>
  <div id="live_data"></div> 
  <p>  <?php  //include 'viewandeditadmins.php';  ?> 
   </p>
</div>

<div id="cc" class="tabcontent">
  <h3> All Courses</h3>
  <div id="live_data_courses"></div> 
  <p> <?php  //include 'coursesforadmin.php';  ?> </p>
</div>

<div id="students" class="tabcontent">
  <h3>Students</h3>
  <p> <?php  include 'viewallstudents.php';  ?> </p>
</div>


<script>
function openTAB(evt, tab) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  console.log(tabcontent);
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(tab).style.display = "block";
  evt.currentTarget.className += " active";
}
// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>
<script src="profile.js">
  
</script>
</div> <!-- End Middle Column -->
    
    <!-- Right Column -->
 
      
  
      
    <!-- End Right Column -->
    </div>
    
  <!-- End Grid -->
  </div>
  
<!-- End Page Container -->
</div>
<br>

<!-- Footer -->
<footer class="w3-container w3-theme-d3 w3-padding-16">
  <h5>Footer</h5>
</footer>


 <!--
<script>
// Accordion
function myFunction(id) {
  var x = document.getElementById(id);
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
    x.previousElementSibling.className += " w3-theme-d1";
  } else { 
    x.className = x.className.replace("w3-show", "");
    x.previousElementSibling.className = 
    x.previousElementSibling.className.replace(" w3-theme-d1", "");
  }
}

// Used to toggle the menu on smaller screens when clicking on the menu button
function openNav() {
  var x = document.getElementById("navDemo");
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
  } else { 
    x.className = x.className.replace(" w3-show", "");
  }
}
</script>
-->

</body>
</html> 
