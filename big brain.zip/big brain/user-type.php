

 <?php $err=$_GET['error']; if(!empty($err)){ echo "<script>alert('$err');</script>"; }?>

<html>

<head>
  <title>User Type</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="fontawesome/css/all.css">
        <link rel="stylesheet" href="fontawesome/css/all.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="userstyle.css">   
</head>

<body>
<?php include('header.php');
session_start(); ?>

<div class="container-x">
    
<form>
<a href="sign up and login.php?ut=<?php echo 'st'?>"><button type="button" id="normall" class="btn btn1" onclick="myFunctionN()"><i class="fas fa-book-reader"><br><br>STUDENT</i></button></a>
<a href="sign up and login.php?ut=<?php echo 'in'?>"><button type="button" id="normall" class="btn btn2" onclick="myFunctionN()"><i class="fas fa-chalkboard-teacher"><br> <br>INSTRUCTOR</i></button></a>
<a href="sign up and loginadmins.php?ut=<?php echo 'ad'?>"><button type="button"id="admin" class="btn btn3"  onclick="myFunction()"><i class="fab fa-angular"><br> <br>ADMINS</i></button></a>
<a href="sign up and loginadmins.php?ut=<?php echo 'hr'?>"> <button type="button" id="hr"class="btn btn4"  onclick="myFunction()"><i class="fas fa-heading"><br> <br>HR</i></button></a>
<a href="sign up and loginadmins.php?ut=<?php echo 'au'?>"><button type="button" id="auditor"class="btn btn5 "  onclick="myFunction()"><i class="fab fa-autoprefixer"><br> <br>AUDITOR</i></button></a>
</form>
</div>


<script>
function myFunctionN() {
 
    window.location.href="http://localhost/big%20brain/sign%20up%20and%20login.php";

}
function myFunction(){
  

    window.location.href="http://localhost/big%20brain/sign%20up%20and%20loginadmins.php";

}
</script>
</body>
</html>
