
<?php 
$msg = ""; 
$errmsg = "";
session_start();
$db = mysqli_connect("localhost", "root", "", "bigbrain"); 

$select_query = "SELECT * FROM customers WHERE email='{$_SESSION['email']}'";
$user_info = mysqli_query($db,$select_query);
$user_info = mysqli_fetch_assoc($user_info);

// If upload button is clicked ... 
if (isset($_POST['upload'])) { 
//Photo Upload START
if(!empty($_FILES["img"]["name"])){
  $target_dir = "uploads/";
  $file_name = mktime().'-'.basename($_FILES["img"]["name"]);
  $target_file = $target_dir . $file_name;
  $uploadOk = 1;
  $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
  // Check if image file is a actual image or fake image
  $check = getimagesize($_FILES["img"]["tmp_name"]);
  if($check !== false) {
    $uploadOk = 1;
  } else {
    $errmsg .= "Failed to upload image: File is not an image.<br>";
    $uploadOk = 0;
  }
  // Check if file already exists
  if (file_exists($target_file)) {
    $errmsg .= "Failed to upload image: File already exists.<br>";
    $uploadOk = 0;
  }
  // Check file size
  if ($_FILES["img"]["size"] > 300000) {
    $errmsg .= "Failed to upload image: File is too large (max: 250KB) <br>";
    $uploadOk = 0;
  }
  // Allow certain file formats
  if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg") {
    $errmsg .= "Failed to upload image: Allowed formats are \"PNG, JPG, JPEG\" <br>";
    $uploadOk = 0;
  }
  if($uploadOk == 1) {
    if (move_uploaded_file($_FILES["img"]["tmp_name"], $target_file)) {
      $sql = "UPDATE customers SET img= '{$target_file}' WHERE email='{$_SESSION['email']}'";
	  	mysqli_query($db, $sql); 
      $_SESSION['image'] = $target_file;
  } else {
      $errmsg .=  "Sorry, there was an error uploading your file.<br>";
    }
  }
}
//Photo Upload END
		
		// Get all the submitted data from the form 
		$sql = "UPDATE customers
    SET name = '{$_POST['name']}',email='{$_POST['email']}',phoneno = '{$_POST['phoneno']}' WHERE email = '{$_SESSION['email']}'";
    if(!empty($_POST['pswd'] && $_POST['pswd'] != "" )){
      $_POST['pswd'] = password_hash($_POST['pswd'],PASSWORD_DEFAULT);
      $password_sql = "UPDATE customers
      SET password = '{$_POST['pswd']}' WHERE email = '{$_SESSION['email']}'";
		  mysqli_query($db, $password_sql); 
    }
    
		// Execute query 
		mysqli_query($db, $sql); 
    $_SESSION['email']=$_POST['email'];
    $_SESSION['name']=$_POST['name'];
    //$_SESSION['image']=$target_file;
    $_SESSION['phoneno']=$_POST['phoneno'];

  $ut=$_SESSION['ut'];
		if($ut=='st'){
      header('Location: profile2.php');
      }
      else if($ut=='in'){
        header('Location: instructorprofile.php');
      }
      else if($ut=='au'){
        header('Location: auditorprofile.php');
      } 
      else if($ut=='hr'){
        header('Location: hrprofile.php');
      }
      else if($ut=='ad'){
        header('Location: adminprofile.php');
      }
     
}  
 if (isset($_POST['delete'])) { 

session_start();

$sql="delete from customers where email='{$_SESSION['email']}'";
$result=mysqli_query($db,$sql);
if($result)
{
	unset($_SESSION['email']);
	session_destroy();
	header("Location:homee.php");
}
else
{
	echo $sql;
}
      }
?> 
<!DOCTYPE html>
<html lang="en">
<head>
  <title>account settings</title>
  <link rel="shortcut icon" type="image/png" href="logo1.png">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head><?php  include('profileheader.php');?>


<style>
  
* {box-sizing: border-box}
body{
    background-color:white;
}
label{
  text-align:center;
  padding:30px 0px 0px 0px;
  font:30px Oswald;
  color: teal;
  text-transform:uppercase;

  margin:0px;
}
input{
   
  text-align:center;
}
p,h2{
  font:13px Open Sans;
  color:teal;
  margin-bottom:30px;
  text-align:center;
}


.form{
  width:$full;
}
  </style>
<body>

<div class="container">
  <form  class="" method="POST" enctype="multipart/form-data">
  <br>
  <br>
    <div class="form-group">
    <label for="name">Name:</label>
      <input type="text" class="form-control" id="name" name="name" value="<?php echo $user_info['name']; ?>" placeholder="Enter your new name"  >
     
      <label for="email">Email:</label>
      <input type="text" class="form-control" id="email" name="email" value="<?php echo $user_info['email']; ?>" placeholder="Enter your new email"  >
     
      <label for="phoneno">Phone no.:</label>
      <input type="text" class="form-control" id="phoneno" name="phoneno" value="<?php echo $user_info['phoneno']; ?>" placeholder="Enter your new phne number"  >
     
    <div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control" id="pwd" placeholder="Enter new password" name="pswd" >
      
   <br>
    <label for="img">Select Profile photo:</label>
    <input type="file" id="img" name="img" accept="image/*">
    </div>
    <button type="submit" name='upload' class="btn btn-primary">Update</button>
    <button type="submit" name='delete' class="btn btn-danger">Delete my account</button>
  </form>
</div>

</body>
</html>


