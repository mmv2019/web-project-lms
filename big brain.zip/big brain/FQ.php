<html>  
      <head>  <link rel="shortcut icon" type="image/png" href="logo1.png">
           <title>frequenty asked</title>  
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
           <?php include('profileheader.php');?>
<style type="text/css">
  
  th{background-color: teal;
    color:white;}
    table{
      width: 100%;
      margin-left: 10%;
      border-collapse: collapse;
      overflow-y:auto;
    }

  button {
  background-color: teal;
  border: none;
  color: white;
  padding: 12px 16px;
  font-size: 16px;
  cursor: pointer;
  margin-bottom: 10px;
}
a{
  cursor: pointer;
  
}

button:hover{background-color: gray;}
</style>
      </head>  
      <body>  
           <div class="container">  
                <br />  
                <br />  
                <br />  
                <div class="table-responsive">  
                     <h3 alignment="center">Add to frequently asked questions</h3><br />  
                     <div id="live_data"></div>                 
                </div>  
           </div>  
           <script>  
 $(document).ready(function(){  
      function fetch_data()  
      {  
           $.ajax({  
                url:"select.php",  
                method:"POST",  
                success:function(data){  
                     $('#live_data').html(data);  
                }  
           });  
      }  
      fetch_data(); 
      $(document).on('click', '.btn_add', function(){
          var id=$(this).data("id3");
          var question = $('#question'+id).text();
          var answer = $('#answer'+id).text();

           if(question == '')  
           {  
                alert("Enter question");  
                return false;  
           }  
           if(answer == '')  
           {  
                alert("Enter answer");  
                return false;  
           }  
           $.ajax({  
                url:"insert.php",  
                method:"POST",  
                data:{question:question, answer:answer},  
                dataType:"text",  
                success:function(data)  
                {  
                     alert(data);  
                     fetch_data();  
                }  
           })  
      });  
 });
</script>



 
      </body>  
 </html>  
