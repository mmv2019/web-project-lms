<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bigbrain";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
if (mysqli_connect_errno()){
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
		die();
		}
?>

<html>
<head>
	<style type="text/css">
		 th{background-color: teal;
    color:white;}
    table{
      width: 100%;
      border-collapse: collapse;
      overflow-y:auto;
    }

  button {
  background-color: teal;
  border: none;
  color: white;
  padding: 12px 16px;
  font-size: 16px;
  cursor: pointer;
  margin-bottom: 10px;
}
a{
  cursor: pointer;

}

button:hover{background-color: gray;}
.user-image-cont{
  width:100px;
  height:100px;
  border-radius:50%;
  overflow:hidden;
}
.user-image-cont img{
  width:100%;
  height:100%;
  object-fit:contain;
  object-position:50% 50%;
}

	</style>
</head>
<body>
<table id="" class="table table-bordered">
<thead>
<tr>
	<th>img</th>
  <th>Name</th>
  <th>Email</th>
  <th>Date Joined</th>
  
</tr>
</thead>
<?php
$sql = "SELECT * FROM customers Where ut='st'";
$result = $conn->query($sql);

while($row = mysqli_fetch_array($result))
{
?>
<tr>
	<td>
  <div class="user-image-cont">
    <img src='<?php echo $row["img"]; ?>' />
  </div>
  </td>
<td><a href="profile2.php?id=<?php echo $row['id']; ?>&ut=<?php echo $_SESSION['ut'];?>"><?php echo $row["name"]; ?></a></td>
  <td><?php echo $row["email"]; ?></td>
  <td><?php echo $row["datejoined"]; ?></td>
</tr>
<?php
}
?>
</table>

</body>
</html>