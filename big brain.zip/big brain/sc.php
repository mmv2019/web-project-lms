<?php
session_start();
$connect = mysqli_connect("localhost", "root", "", "bigbrain");
$courses = array();
if (isset($_POST["add_to_cart"])) {
    $sid = $_SESSION['id'];
    $cid = $_POST['id'];
    $query = "INSERT INTO cart (course_id, student_id) VALUES ('$cid', '$sid')";
    $result = mysqli_query($connect, $query);
    if($result){
        echo "<script>alert('Course added successfully.')</script>";
    }
    else {
        echo "<script>alert('Error adding course.')</script>";
    }
}

?>
<!DOCTYPE html>
<html>
<head>
    <title></title><link rel="shortcut icon" type="image/png" href="logo1.png">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"/>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>

<?php include('profileheader.php'); ?>
<br><br><br>
<a href="checkout.php" class="btn btn-success" style="float:right; margin-right:5%; padding :25px;"><i
            class="fa fa-shopping-cart"></i></a>
<div class="container" style="width:700px;">
    <h3 align="center"></h3><br/>
    <?php
    $query = "SELECT * FROM course ORDER BY id ASC";
    $result = mysqli_query($connect, $query);
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_array($result)) {
            ?>
            <div class="col-md-4">
                <form method="post" action="sc.php">
                    <div style="border:1px solid #333; background-color:#f1f1f1; border-radius:5px; padding:16px;"
                         align="center">
                        <img src="<?php echo $row["img"]; ?>" class="img-responsive"/><br/>
                        <h4 class="text-info"><?php echo $row["name"]; ?></h4>
                        <h4 class="text-danger">$ <?php echo $row["price"]; ?></h4>
                        <input type="hidden" name="id" value="<?php echo $row["id"]; ?>"/>
                        <input type="submit" name="add_to_cart" style="margin-top:5px;" class="btn btn-success"
                               value="Add to Cart"/>
                    </div>
                </form>
            </div>
            <?php
        }
    }
    ?>
    <div style="clear:both"></div>
    <br/>
    <br/>
</body>
</html>