<?php  
	$connect = mysqli_connect("localhost", "root", "", "bigbrain");
	$coursename= $_POST["coursename"];  
	$price = $_POST["price"];  
	$instructor = $_POST["instructor"];  
	$description = $_POST["description"];
	$id=$_POST['id']; 
	//$instructor = $_POST["instructor"]; 
	#$sql = "UPDATE course SET ".$column_name."='".$text."' WHERE id='".$id."'";
	$sql = "UPDATE course SET name='$coursename',price='$price',instructor='$instructor',description='$description' WHERE id='{$id}'";
	if(mysqli_query($connect, $sql))  
	{  
		echo 'Data Updated';  
	}  
 ?>