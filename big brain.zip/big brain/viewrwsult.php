
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-teal.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans'>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<br><br>
<br>
<br>
<?php  
include('profileheader.php');
 $connect = mysqli_connect("localhost", "root", "", "bigbrain");  
 $output = '';  
 $sql = "SELECT * FROM survay ";  
 $result = mysqli_query($connect, $sql);  
 $output .= '  
      <div class="table-responsive">  
           <table class="table table-bordered">  
                <tr>
                  <th width="40%">Question 1</th>
                  <th width="40%">Question 2</th> 
                  <th width="40%">Question 3</th>
                       
                  <th width="40%">Question 4</th>
                  <th width="40%">Question 5</th>
                </tr>';  
 if(mysqli_num_rows($result) > 0)  
 {  
      while($row = mysqli_fetch_assoc($result))  
      {  
           $output .= '  
                <tr>  
                
                     <td class="email" id="email" data-id1="'.$row["id"].'" >'.$row["q1"].'</td>  
                     <td class="email" id="email" data-id2="'.$row["id"].'" >'.$row["q2"].'</td>  
                     <td class="email" id="email" data-id3="'.$row["id"].'" >'.$row["q3"].'</td>  
                     <td class="email" id="email" data-id4="'.$row["id"].'" >'.$row["q4"].'</td>  
                     <td class="email" id="email" data-id5="'.$row["id"].'" >'.$row["q5"].'</td>  
                    
                </tr>  
           ';  
        }  
       
 }  
 else  
 {  
      $output .= '<tr>  
                          <td colspan="4">Data not Found</td>  
                     </tr>';  
 }  
 $output .= '</table>  
      </div>';  
 echo $output;  
 ?>