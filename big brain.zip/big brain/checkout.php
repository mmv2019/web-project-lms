<?php
session_start();
$connect = mysqli_connect("localhost", "root", "", "bigbrain");
if (isset($_GET["action"])) {
    if ($_GET["action"] == "delete") {
        $id = $_GET['id'];

        $query = "DELETE FROM cart WHERE course_id = '$id'";
        $result = mysqli_query($connect, $query);
        if($result){
            echo "<script>alert('Course removed successfully.')</script>";
        }
        else {
            echo "<script>alert('Error removing course.')</script>";
        }
    }
}

if(isset($_POST['checkout']))
{
    header('Location:payment.php');
}
$studentname = $_SESSION['name'];
$studentid = $_SESSION['id'];
$query = "SELECT * FROM course WHERE id = ";

$query2 = "SELECT * FROM cart WHERE student_id = '$studentid'";
$result2 = mysqli_query($connect, $query2);
if ($result2) {
    if (mysqli_num_rows($result2) > 0) {
        while ($row = mysqli_fetch_array($result2)) {
            $query .= $row[1] . " OR id = ";
        }
        $query = substr($query, 0, -9);
    }
}
$result = mysqli_query($connect, $query);
?>
<html>
<head><link rel="shortcut icon" type="image/png" href="logo1.png">
    <title>Check Out</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"/>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <style>
        table {
            margin-left: 10%;
            padding: 10px;
        }
    </style>
</head>
<body>
<?php include('profileheader.php'); ?>
<h3 style="margin-left:10%;">Order Details</h3>
<br>
<div class="table-responsive">
    <table class="table table-stripped" style="width:70%;">
        <tr>
            <th>Item Name</th>
            <th>Price</th>
            <th>Action</th>
            <th>Total</th>
        </tr>
        <?php $id='';
        $total = 0;
        if ($result) {
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_array($result)) { $total += $row[3];?>
                    <tr>
                        <td><?php echo $row[0]; ?></td>
                        <td><?php echo $row[3]; ?></td>
                        <td><a href="checkout.php?action=delete&id=<?php echo $row[4];?>"><span class="text-danger">Remove</span></a>
                        </td>
                    </tr>

                <?php $id.=$row[4].','; }
            }
        }
        ?>


        <tr>
            <td colspan="3" align="right"></td>
            <td>$ <?php echo $total;?> </td>
            <td></td>
        </tr>


    </table>
</div>
<form method="post" action="payment.php?id=<?php echo $id ?> ">
<input type="hidden" name="id" value="<?php echo $_GET['id']?>">
    <button style="padding:10px; float:right; background-color:teal; margin-right:10%;" type="submit" name="checkout">
        Check Out
    </button>
</form>

</body>
</html>