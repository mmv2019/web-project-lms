<?php  
	$connect = mysqli_connect("localhost", "root", "", "bigbrain");
	$sql = "DELETE FROM course WHERE id= '".$_POST["id"]."'";

	if(mysqli_query($connect, $sql))  
	{  
		echo 'Data course Deleted';  
	}  
 ?>