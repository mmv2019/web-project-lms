<?php  
$password =password_hash('123',PASSWORD_DEFAULT);
$connect = mysqli_connect("localhost", "root", "", "bigbrain");
if(!filter_var($_POST["email"],FILTER_VALIDATE_EMAIL)){
     echo 'Please enter a valid email';
exit;
}
$sql = "INSERT INTO customers(name, email,ut,password ,datejoined,img, warning) VALUES('".$_POST["name"]."', '".$_POST["email"]."', 'ad','{$password}',NOW(),'img/profile.png', 'No warnings yet :)' )";  
if(mysqli_query($connect, $sql))  
{  
     echo 'Data Inserted';  
}  
 ?>