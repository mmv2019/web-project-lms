var tab_buttons = document.querySelectorAll('.tab-button');
var tabs = document.querySelectorAll('.tab');
for(let i =0; i<tab_buttons.length; i++){
    tab_buttons[i].addEventListener('click',function(){
        for(let j = 0; j<tab_buttons.length;j++){
            tab_buttons[j].classList.remove('active');
        }
        for(let j = 0; j<tabs.length;j++){
            tabs[j].style.display ="none";
        }
        this.classList.add('active');
        tabs[i].style.display="block";
        
    });
}