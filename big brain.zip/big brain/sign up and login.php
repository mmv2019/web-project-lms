<?php include('header.php');
if(!isset($_GET['ut'])){
    header('Location:./user-type.php');
    exit;
}
?>
<html>
    <head>
        <title>Login and sign up form</title>
        <link rel="stylesheet" href="s.css">
        
        <?php 
        if(isset($_GET['error'])){
        ?>
        <script>alert("<?php echo $_GET['error'];?>")</script>
        <?php }
        ?>
    </head>
    
<body>
    <div class="hero">
        <div class="form-box">
            <div class="button-box">
                <div id="btn"></div>
                <button type="button" class="toggle-btn" onclick="login()">Log In</button>
                <button type="button" class="toggle-btn" onclick="signup()">Sign Up</button>
          </div>   
          <div class="icon">
               <img src='Logo1.png'>
           </div>
            
        <form id="login" class="input-group" action="mm.php" method="post">
            <input type="text" name='Email'class="input-field" placeholder="Email" required>
            <input type="password" name="pass" class="input-field" placeholder="Enter password" required><p><br></p>
            <input type="hidden" name="type" value="<?php echo $_GET['ut']?>">
              <button type="submit" name="Submit" class="submit-btn" >Log in</button>        
            <div id="statusMessage"> 
                        <?php
                        if (! empty($_GET['error'])) {
                            ?>
                            <p class='Message'><?php echo $_GET['error']; ?></p>
                        <?php
                        }
                        ?>
                    </div>
        </form>
       <form id="signup" class="input-group was-validated" action="register.php" method="POST">
            <input type="text" name="Name" class="input-field" placeholder="Name" required>
            <input type="email" name="Email" class="input-field" placeholder="Email" required>
            <input type="text" name="phoneno" class="input-field" placeholder="Phone number" required>
            <input type="password" name="pass" class="input-field" placeholder="Enter password" required>
            <input type="password" name='conpass' class="input-field" placeholder="Confirm password" required><p></p>
            <input type="hidden" name="type" value="<?php echo $_GET['ut']?>">
           <button type="submit" name='reg_user'class="submit-btn" >Sign Up</button>
          
            <div id="statusMessage"> 
                        <?php
                        if (! empty($_GET['error'])) {
                            ?>
                            <p class='Message'> <?php if (!empty($GLOBALS['errors'])) {echo $GLOBALS['errors']; }?></p>
                        <?php
                        }
                        ?>
                        <?php if (!empty($GLOBALS['errors'])) echo $GLOBALS['errors']; ?>
   
        </form>
        </div>
    </div>
    <script>
        var x=document.getElementById("login");
        var y=document.getElementById("signup");
        var z=document.getElementById("btn");

        function signup(){
            x.style.left='-400px';
            y.style.left='50px';
            z.style.left='110px';
        }

        function login(){
          x.style.left='50px';
           y.style.left='450px';
            z.style.left='0px';
       
        }
       
       


    </script>
</body>
</html>