

<?php 
session_start();
$email=$_SESSION['email'];
$name=$_SESSION['name'];
$no=$_SESSION['phoneno'];
$img=$_SESSION['image'];
$ut=$_SESSION['ut'];
 if($ut='au'){$page='../auditorprofile.php';}
 else if($ut='st'){$page='../profile2.php';}
 else if($ut='in'){$page='../instructorprofile.php';}
 else if($ut='ad'){$page='../adminprofile.php';}
 else if($ut='hr'){$page='../hrprofile.php';}

?>
<html>
<title> Auditor</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-teal.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans'>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/themes/smoothness/jquery-ui.min.css" />
<link rel="stylesheet" href="../fontawesome/css/all.css">
        <link rel="stylesheet" href="../fontawesome/css/all.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
html, body, h1, h2, h3, h4, h5 {font-family: "Open Sans", sans-serif}

. nav
{
    width:100%;
    z-index: -1;
    
}
.navbar{
    background:teal;
}
.nav ul{
    display: flex;
    justify-content: center;
    list-style-type: none;
    height: 40px;
    background: #fff;
    box-shadow: 0px 2px 5px rgba(0,0,0,.3);
}
.nav ul li{
    padding:10px;
    width:100%;
    cursor: pointer;
    text-align: center;
    transition: all .2s ease-in-out;
}
.nav ul li.active,
.nav ul li:hover{
    box-shadow: 0px -3px 0px teal inset;
    color:wheat;
}

</style>
<body class="w3-theme-14">

<!-- Navbar -->
<div class="w3-top">
 <div class="w3-bar w3-theme-d2 w3-left-align w3-large">
  <a class="w3-bar-item w3-button w3-hide-medium w3-hide-large w3-right w3-padding-large w3-large w3-theme-teal" href="javascript:void(0);" onclick="openNav()"><i class="fa fa-bars"></i></a>
  <a href="../homee.php" class="w3-bar-item w3-button w3-padding-large w3-hover-red"><i class="fa fa-home w3-margin-right"></i>BIG BRAIN</a>
  <a href="../account settings.php" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-red" title="Account Settings"><i class="fas fa-user-cog"></i></a>
  <a href="index.php" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-red" title="Messages"><i class="fas fa-comment-dots"></i></a>
  <div class="w3-dropdown-hover w3-hide-small w3-hover-red">
    
  </div>
  <a href="../sign out.php" class="w3-bar-item w3-button w3-hide-small w3-right w3-padding-large " title="sign out"><i class="fas fa-sign-out-alt"></i></a>
 
  

  <a href="#" onclick="doClick(); return false;" class='w3-bar-item w3-button w3-hide-small w3-right w3-padding-large w3-hover-white'><img class="w3-circle" style="height:30px;width:30px;" src='<?php echo '../'.$_SESSION['image']?>'></a>

<script>

function doClick() {var type = "<?php echo $_SESSION['ut'] ?>";
    if(type=='st')
{  window.location.href = "../profile2.php";}
else if(type=='in')
{  window.location.href = "../instructorprofile.php";}
else if(type=='au')
{  window.location.href = "../auditorprofile.php";}
else if(type=='ad')
{  window.location.href = "../adminprofile.php";}
else if(type=='hr')
{  window.location.href = "../hrprofile.php";}
 }
</script>
 </div>
</div>




</body>
         </html>