<?php

//logout.php

session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bigbrain";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);



$sql="SELECT * FROM customers WHERE email='{$_SESSION['email']}'";
		$result = mysqli_query($conn,$sql);
		echo $conn->error;
		if($row=mysqli_fetch_assoc($result))
		{

			$_SESSION['ut']=$row['ut'];
			
			if($ut=='st'){
				header('Location: profile2.php');
				}
				else if($ut=='in'){
				  header('Location: instructorprofile.php');
				}
				else if($ut=='au'){
				  header('Location: auditorprofile.php');
				} 
				else if($ut=='hr'){
				  header('Location: instructorprofile.php');
				}
				else if($ut=='ad'){
					header('Location: adminprofile.php');
				  }
                }
                session_destroy();
?>