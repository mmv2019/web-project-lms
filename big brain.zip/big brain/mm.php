<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bigbrain";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

	
 //check if form was submitted
	
if(isset($_POST['Submit'])){ 

	$ut = $_POST['type'];
	
//check if form was submitted
//without decreption
	$pswd = $_POST['pass'];
	$database_password = "SELECT password,ut FROM customers WHERE email='{$_POST['Email']}'";
	$database_password = mysqli_query($conn,$database_password);
	var_dump($database_password);
	echo $conn->error;
	$row = mysqli_fetch_assoc($database_password);
	if(password_verify($pswd,$row['password'])&&$row['ut']==$ut){
		$sql="SELECT * FROM customers WHERE email='{$_POST['Email']}'";
		$result = mysqli_query($conn,$sql);
		echo $conn->error;
		if($row=mysqli_fetch_assoc($result))
		{
			
			$_SESSION["name"]=$row['name'];
			$_SESSION["email"]=$row['email'];
			$_SESSION['phoneno']=$row['phoneno'];
			$_SESSION['datejoined']=$row['datejoined'];
			$_SESSION['image']=$row['img'];
			$_SESSION['ut']=$row['ut'];
			$_SESSION['id']=$row['id'];
			if($ut=='st'){
				header('Location: profile2.php');
				}
				else if($ut=='in'){
				  header('Location: instructorprofile.php');
				}
				else if($ut=='au'){
				  header('Location: auditorprofile.php');
				} 
				else if($ut=='hr'){
				  header('Location: hrprofile.php');
				}
				else if($ut=='ad'){
					header('Location: adminprofile.php');
				  }
		}
		else
		{
		header("Location:user-type.php");
		}
	}else{
		echo "<h3>Make sure you choose the right user type !! Or check ur password</h3>";
		header("Location:user-type.php?error=INVALID data!");
	}
	
}
?>
