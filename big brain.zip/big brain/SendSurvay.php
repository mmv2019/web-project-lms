<?php
session_start();
//connect database
$server = "localhost";
 $username = "root";
$password = "";
$DB = "bigbrain";

$conn = mysqli_connect($server,$username,$password,$DB);
if (isset($_POST['submit'])) 
{

    $q1 = $_POST['q1'];
    $q2 = $_POST['q2'];
    $q3 = $_POST['q3'];
    $q4 = $_POST['q4'];
    $q5 = $_POST['q5'];
    $feedback=$_POST['feedback'];
    
    $sql = "INSERT INTO survay (q1,q2,q3,q4,q5,user_id,feedback) VALUES ('{$_POST['q1']}','{$_POST['q2']}','{$_POST['q3']}' ,'{$_POST['q4']}','{$_POST['q5']}','{$_SESSION['id']}',,'{$_POST['feedback']}')";
    $result = mysqli_query($conn,$sql);
    if($result){
    print '<script>alert("submit successfuly!");</script>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <style>
       
    
    background-image: url('https://blog.goreact.com/wp-content/uploads/sites/2/2017/02/feedback-online.jpg');

    html, body, h1, h2, h3, h4, h5 {font-family: "Open Sans", sans-serif}

input[type=radio], input[type=int] {
  width: 100%;
border: none;
  background: #f1f1f1;
 
}

input[type=radio]:focus, input[type=int]:focus {
  background-color: #ddd;
  outline: none;
  
}

p { text-align: center;
    padding: 14px 16px;
 
 }
 h3{
  
    font-size:25px;
    margin-left: 260px;
 }

body{
    background: #0c9992;
    overflow-x: hidden;
    padding-top: 90px;
    font-family: "poppins",sans-serif;
    margin:0 100;
}
.container {
    text-align: center;
    float:middle;
    font-size: 22px;
}
.header{
    float:middle;
    left:100px;
    background: #ffffff;
    width:70%;
    display:flex;
    height:2200px;
    position:relative;
    box-shadow: 0px 3px 4px rgba(0,0,0,.2);
    
}
.submit-btn{
    float:middle;
  width:47%;
  padding:15px;
  border-radius:5px;
  @include disable;
  margin-left: 260px;
  background-color:#FF6347;
  font:14px tomato;
  color:#FFF;
  text-transform:uppercase;
  text-shadow:#000 0px 1px 5px;
  border:1px solid #000;
  display:block;
}


    </style>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,400;0,500;0,600;1,300;1,400;1,500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">

    
    <title> survay</title>
    
    
</head>
<body>
<h3>Thank you for taking the time to help us improve our website.</h3>

<div class="container">

    <hearder class="header">
        <h1 id="title">
          
        </h1>
     
        
</header>
<div class="formm">
<form method="POST">
    <div class="survay-group">
  
       <b> <p id="user">1)The instructor was well prepared for the class.</p></b>
        <label for="">
            <input type="radio"
            name="q1"
            value="Almost always"
            class="input radio"
            checked>Almost always
</label><br>
<label for="">
            <input type="radio"
            name="q1"
            value="Frequently"
            class="input radio"
            checked>Frequently
</label><br>
<label for="">
            <input type="radio"
            name="q1"
            value="sometimes"
            class="input radio"
            checked>sometimes
</label><br>
<label for="">
            <input type="radio"
            name="q1"
            value="rarely"
            class="input radio"
            checked>rarely
</label><br>
<label for="">
            <input type="radio"
            name="q1"
            value="almost never"
            class="input radio"
            checked>almost never
</label><br>
<div class="survay-group">
      <b>  <p id="user">2)The instructor showed an interested in helpinf student learn.</p></b>
        <label for="">
            <input type="radio"
            name="q2"
            value="Almost always"
            class="input radio"
            checked>Almost always
</label><br>
<label for="">
            <input type="radio"
            name="q2"
            value="Frequently"
            class="input radio"
            checked>Frequently
</label><br>
<label for="">
            <input type="radio"
            name="q2"
            value="sometimes"
            class="input radio"
            checked>sometimes
</label><br>
<label for="">
            <input type="radio"
            name="q2"
            value="Rarely"
            class="input radio"
            checked>Rarely
</label><br>
<label for="">
            <input type="radio"
            name="q2"
            value="almost never"
            class="input radio"
            checked>almost never
</label><br>
<div class="survay-group">
        <b><p id="user">3)I received useful feedback on my performance on tests,paper,etc..</p></b>
        <label for="">
            <input type="radio"
            name="q3"
            value="Almost always"
            class="input radio"
            checked>Almost always
</label><br>
<label for="">
            <input type="radio"
            name="q3"
            value="Frequently"
            class="input radio"
            checked>Frequently
</label><br>
<label for="">
            <input type="radio"
            name="q3"
            value="sometimes"
            class="input radio"
            checked>sometimes
</label><br>
<label for="">
            <input type="radio"
            name="q3"
            value="Rarely"
            class="input radio"
            checked>Rarely
</label><br>
<label for="">
            <input type="radio"
            name="q3"
            value="Almost never"
            class="input radio"
            checked>Almost never
</label><br>
<div class="survay-group">
       <b> <p id="user">4)The course was organized in a manner that helped me understand the underlying concept.</p></b>
        <label for="">
            <input type="radio"
            name="q4"
            value="Strongly agree"
            class="input radio"
            checked>Strongly agree
</label><br>
<label for="">
            <input type="radio"
            name="q4"
            value="Agree"
            class="input radio"
            checked>Agree
</label><br>
<label for="">
            <input type="radio"
            name="q4"
            value="neutral"
            class="input radio"
            checked>neutral
</label><br>
<label for="">
            <input type="radio"
            name="q4"
            value="Disagree"
            class="input radio"
            checked>Disagree
</label><br>
<label for="">
            <input type="radio"
            name="q4"
            value="Strongly disagree"
            class="input radio"
            checked>Strongly disagree
</label><br>
<div class="survay-group">
        <b><p id="user">5)The instructor showed an interested in helpinf student learn.</p></b>
        <label for="">
            <input type="radio"
            name="q5"
            value="Almost always"
            class="input radio"
            checked>Almost always
</label><br>
<label for="">
            <input type="radio"
            name="q5"
            value="Frequently"
            class="input radio"
            checked>Frequently
</label><br>
<label for="">
            <input type="radio"
            name="q5"
            value="sometimes"
            class="input radio"
            checked>sometimes
</label><br>
<label for="">
            <input type="radio"
            name="q5"
            value="Rarely"
            class="input radio"
            checked>Rarely
</label><br>
<label for="">
            <input type="radio"
            name="q5"
            value="almost never"
            class="input radio"
            checked>almost never
</label><br>
<div class="survay-group">
        <b><p id="user">Give us your feedback</p></b>
        <textarea name="feedback"
        id="feedback"cols="60"
        rows="10"class="textarea"
        placeholder="Eenter your feedback here"></textarea>
</div>
        <button type="submit" name="submit" class="submit-btn" >submit</button>
   

</div>
</div>
</form>

</body>
</html>