
<?php
session_start();


$Email = $_POST['Email'];
$Password = $_POST['pass'];
// preventing injection
/*$Email= stripcslashes($Email);
$Password=stripcslashes($Password);
$Email=mysql_real_escape_string($Email);
$Password=mysql_real_escape_string($Password);*/

$servername = "localhost";
$username = "root";

$dbname = "big brain";

// Create connection
$conn = new mysqli($servername, $username, '', $dbname);
if(isset($_POST['Submit'])){ echo '-----';
$sql="SELECT * FROM students WHERE Email='$Email' AND password='$Password'";
	$result = mysqli_query($conn,$sql);		
 //check if form was submitted
	if($row=mysqli_fetch_array($result))
	//if($row['Email']==$Email&&$row['Password']==$Password)	
	{
		$_SESSION["Email"]=$row[1];
		$_SESSION["pass"]=$row[2];
        echo 'LOGIN SUCESSFULLY!!!!!!!!';
	//	header("Location:home.php");
	}
	else	
	{
		echo"Invalid Email or Password";
	}
}
?>