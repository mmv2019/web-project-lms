
<?php 
session_start();
?>
<html>

<head>
  <title>Survey</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="fontawesome/css/all.css">
        <link rel="stylesheet" href="fontawesome/css/all.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="userstyle.css">   
</head>

<body>
<?php include('profileheader.php');
?>

<div class="container-x">
    
<form>
<button type="button" id="normall" class="btn btn1" style='width:350px' onclick="myFunctionN()"><i class="fas fa-poll-h"><br><br>view survey</i></button></a>
<button type="button" id="normall" class="btn btn2" style='width:350px' onclick="myFunction()"><i class="fas fa-percent"><br> <br>view survey results</i></button></a>

</form>
</div>


<script>
function myFunctionN() {
 
    window.location.href="http://localhost/big%20brain/SendSurvay.php";

}
function myFunction(){
  

    window.location.href="http://localhost/big%20brain/viewrwsult.php";

}
</script>
</body>
</html>
