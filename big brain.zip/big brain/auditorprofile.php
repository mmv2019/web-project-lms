
<?php 
session_start();
if($_SESSION['ut']!='au'){
  header('Location:./user-type.php');
  exit;
}
$email=$_SESSION['email'];
$name=$_SESSION['name'];
$no=$_SESSION['phoneno'];
$img=$_SESSION['image'];
$datejoined=$_SESSION['datejoined'];

?>
<html>
<title> Auditor</title><link rel="shortcut icon" type="image/png" href="logo1.png">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-teal.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans'>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/themes/smoothness/jquery-ui.min.css" />
<link rel="stylesheet" href="fontawesome/css/all.css">
<link rel="stylesheet" href="fontawesome/css/all.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
html, body, h1, h2, h3, h4, h5 {font-family: "Open Sans", sans-serif}

. nav
{
    width:100%;
    z-index: -1;
    
}
.navbar{
    color:#0c9992;
}
.nav ul{
    display: flex;
    justify-content: center;
    list-style-type: none;
    height: 40px;
    background: #fff;
    box-shadow: 0px 2px 5px rgba(0,0,0,.3);
}
.nav ul li{
    padding:10px;
    width:100%;
    cursor: pointer;
    text-align: center;
    transition: all .2s ease-in-out;
}
.nav ul li.active,
.nav ul li:hover{
    box-shadow: 0px -3px 0px teal inset;
    color:wheat;
}

</style>
<body class="w3-theme-14">

<!-- Navbar -->
<div class="w3-top">
 <div class="w3-bar w3-theme-d2 w3-left-align w3-large">
  <a class="w3-bar-item w3-button w3-hide-medium w3-hide-large w3-right w3-padding-large w3-large w3-theme-teal" href="javascript:void(0);" onclick="openNav()"><i class="fa fa-bars"></i></a>
  <a href="homee.php" class="w3-bar-item w3-button w3-padding-large w3-hover-red"><i class="fa fa-home w3-margin-right"></i>BIG BRAIN</a>
  <a href="account settings.php" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-red" title="Account Settings"><i class="fas fa-user-cog"></i></a>
  <a href="chat/index.php" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-red" title="Messages"><i class="fas fa-comment-dots"></i></a>
  <div class="w3-dropdown-hover w3-hide-small w3-hover-red">
    
  </div>
  <a href="sign out.php" class="w3-bar-item w3-button w3-hide-small w3-right w3-padding-large " title="sign out"><i class="fas fa-sign-out-alt"></i></a>
  <a href="#" class="w3-bar-item w3-button w3-hide-small w3-right w3-padding-large w3-hover-white" title="My Account">
    <img src="<?php echo $img; ?>"  class="w3-circle" style="height:23px;width:23px" alt="Avatar">
  </a>
 </div>
</div>

<!-- Navbar on small screens -->
<div id="navDemo" class="w3-bar-block w3-theme-d2 w3-hide w3-hide-large w3-hide-medium w3-large">
  <a href="#" class="w3-bar-item w3-button w3-padding-large">Link 1</a>
  <a href="#" class="w3-bar-item w3-button w3-padding-large">Link 2</a>
  <a href="#" class="w3-bar-item w3-button w3-padding-large">Link 3</a>
  <a href="#" class="w3-bar-item w3-button w3-padding-large">My Profile</a>
</div>

<!-- Page Container -->
<div class="w3-container w3-content" style="max-width:1400px;margin-top:80px">    
  <!-- The Grid -->
  <div class="w3-row">
    <!-- Left Column -->
    <div class="w3-col m3">
      <!-- Profile -->
      <div class="w3-card w3-round w3-white">
        <div class="w3-container">
         <h4 class="w3-center">Auditor Profile</h4>
         <p class="w3-center"><img src="<?php echo $img; ?>" class="w3-circle" style="height:106px;width:106px;" alt="Avatar"></p>
         <hr>
         <p><i class="fa fa-pencil fa-fw w3-margin-right w3-text-theme"></i><?php echo $name?></p>
         <p><i class="fas fa-at fa-fw w3-margin-right w3-text-theme"></i> <?php echo $email?></p>
         <p><i class="far fa-clock fa-fw w3-margin-right w3-text-theme"></i> <?php echo $datejoined?></p>
        </div>
      </div>
      <br>
      
      <!-- Accordion -->
      <div class="w3-card w3-round w3-theme-d1">
        <div class="w3-theme">
  
          <button onclick="document.location='FQ.php'" class="w3-button w3-block w3-theme-d1 w3-left-align"><i class="fas fa-sticky-note w3-margin-right"></i> Freqently Questions</button>
          <div id="Demo2" class="w3-hide w3-container">
            <p>Some other text..</p>
          </div>

        </div>      
      </div>
      <br>

     
      

    
    <!-- End Left Column -->
    </div>
    
       <!-- Middle Column -->
       <div class="w3-col m7">
    
        <button onclick="document.location='send.php'" class="w3-button w3-block w3-theme-d1 w3-center-align " style="max-width:5%;margin-left:500px;padding:20%;margin-top:25px;border-radius: 8px;"  ><i class="fas fa-paper-plane"></i> Send to HR</button>   
        <button onclick="document.location='surveyau.php'" class="w3-button w3-block w3-theme-d1 w3-center-align " style="max-width:10%;margin-left:100px;padding:20%;margin-top:-340px;border-radius: 8px;"  ><i class="fas fa-sticky-note w3-margin-center"></i> Survay</button>   
    
        <div class="profile-body w3-center">
            <div class="profile-posts tab">
               
                
            </div>
            
</div>
</div>



</div>
  <!-- End Middle Column -->
  
  </div>
  
  <!-- Right Column -->
 
    
   
    
  <!-- End Right Column -->
  </div>
  
<!-- End Grid -->
</div>

<!-- End Page Container -->
</div>
<br>
<footer class="w3-container w3-theme-d3 w3-padding-16">
<h5></h5>
</footer>

<footer class="w3-container w3-theme-d5">
<p></p>
</footer>
<!-- Footer -->

<script>
// Accordion
function myFunction(id) {
var x = document.getElementById(id);
if (x.className.indexOf("w3-show") == -1) {
  x.className += " w3-show";
  x.previousElementSibling.className += " w3-theme-d1";
} else { 
  x.className = x.className.replace("w3-show", "");
  x.previousElementSibling.className = 
  x.previousElementSibling.className.replace(" w3-theme-d1", "");
}
}

// Used to toggle the menu on smaller screens when clicking on the menu button
function openNav() {
var x = document.getElementById("navDemo");
if (x.className.indexOf("w3-show") == -1) {
  x.className += " w3-show";
} else { 
  x.className = x.className.replace(" w3-show", "");
}
}
</script>

</body>
</html> 
