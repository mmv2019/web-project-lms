<?php  
 $connect = mysqli_connect("localhost", "root", "", "bigbrain"); 
 $question= $_POST["question"];
$answer=$_POST["answer"];

 $sql = "INSERT INTO frequently(question, answer) VALUES('$question', '$answer')";
 if( mysqli_query($connect,$sql))  
 {  
    echo "Data has been inserted"; 
 }  
 else{
    echo "Welcome to Geeks for Geeks"; 
 }
 ?>