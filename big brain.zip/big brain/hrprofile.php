<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bigbrain";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

if($_SESSION['ut']!='hr'){
  header('Location:./user-type.php');
  exit;
}
$Email=$_SESSION['email'];
$Name=$_SESSION['name'];
$no=$_SESSION['phoneno'];
$img=$_SESSION['image'];
$datejoined=$_SESSION['datejoined'];

?>

<!DOCTYPE html>
<html>
 <head> 
<title>HR Profile</title><link rel="shortcut icon" type="image/png" href="logo1.png">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-teal.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans'>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<!-- CSS vertical tab -->
<link rel="stylesheet" href="vertical-tab-admin.css">

<!-- M3RFSH BTO3 EH DOL BS MARYAM HATAHOM -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/themes/smoothness/jquery-ui.min.css" />
<!--<link rel="stylesheet" href="fontawesome/css/all.css">
        <link rel="stylesheet" href="fontawesome/css/all.min.css"> -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- datejoined icon -->
<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>


<style>
html, body, h1, h2, h3, h4, h5 {font-family: "Open Sans", sans-serif}

th {
     background-color:teal;
}

</style>

<link rel="shortcut icon" type="image/png" href="logo1.png">
</head>
<body class="w3-theme-14">

<!-- Navbar -->
<div class="w3-top">
 <div class="w3-bar w3-theme-d2 w3-left-align w3-large">
  <a class="w3-bar-item w3-button w3-hide-medium w3-hide-large w3-right w3-padding-large w3-large w3-theme-teal" href="javascript:void(0);" onclick="openNav()"><i class="fa fa-bars"></i></a>
  <a href="homee.php" class="w3-bar-item w3-button w3-padding-large w3-hover-white"><i class="fa fa-home w3-margin-right"></i>BigBrain</a>

  <a href="account settings.php" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-red" title="Account Settings"><i class="fas fa-user-cog"></i></a>
  <a href="chat/index.php" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-red" title="Messages"><i class="fas fa-comment-dots"></i></a>
  <div class="w3-dropdown-hover w3-hide-small w3-hover-white">
  </div>
  <a href="sign out.php" class="w3-bar-item w3-button w3-hide-small w3-right w3-padding-large " title="sign out"><i class="fas fa-sign-out-alt"></i></a>
  <a href="#" class="w3-bar-item w3-button w3-hide-small w3-right w3-padding-large w3-hover-white" title="My Account">
    <img src="<?php echo $img; ?>"  class="w3-circle" style="height:23px;width:23px" alt="Avatar">
  </a>
 </div>
</div>

<!-- Navbar on small screens -->
<div id="navDemo" class="w3-bar-block w3-theme-d2 w3-hide w3-hide-large w3-hide-medium w3-large">
  <a href="#" class="w3-bar-item w3-button w3-padding-large">Link 1</a>
  <a href="#" class="w3-bar-item w3-button w3-padding-large">Link 2</a>
  <a href="#" class="w3-bar-item w3-button w3-padding-large">Link 3</a>
  <a href="#" class="w3-bar-item w3-button w3-padding-large">My Profile</a>
</div>

<!-- Page Container -->
<div class="w3-container w3-content" style="max-width:1400px;margin-top:80px">    
  <!-- The Grid -->
  <div class="w3-row">
    <!-- Left Column -->
    <div class="w3-col m3">
      <!-- Profile -->
      <div class="w3-card w3-round w3-white">
        <div class="w3-container">
         <h4 class="w3-center">My Profile</h4>
         <p class="w3-center"><img src="<?php echo $img; ?>" class="w3-circle" style="height:106px;width:106px" alt="Avatar"></p>
         <hr>

         <p><i class="fa fa-id-card fa-fw w3-margin-right w3-text-theme"></i> <?php echo $Name;?></p>
         <p><i class="fa fa-envelope fa-fw w3-margin-right w3-text-theme"></i> <?php echo $Email ?></p>
         <p><i class="fas fa-calendar fa-fw w3-margin-right w3-text-theme"></i> <?php echo $_SESSION["datejoined"]; ?></p>
        </div>
      </div>
      <br>
      
   <!-- Accordion -->
   <div class="w3-card w3-round w3-theme-d1 tab">
        <div class="w3-theme">
          <button onclick= "openTAB(event, 'view')" id="defaultOpen"  class=" tablinks w3-button w3-block w3-theme-d1 w3-left-align"><i class="fa fa-user-plus fa-fw w3-margin-right"></i>Misbehaviour</button>
                    
          <button onclick= "openTAB(event, 'send')"  class="tablinks w3-button w3-block w3-theme-d1 w3-left-align"><i class="fa fa-users fa-fw w3-margin-right"></i> Send a Penalty</button>
          
          </div>
        </div>      
      </div>
      <br>
     
    <!-- End Left Column -->
   <!-- </div> -->
    
   
        

   <!-- <div class="w3-col m7 " style="margin-left:25%; padding-top:0px;"> -->
    
       <?php
       // include 'viewandeditadmins.php';
      //include 'coursesforadmin.php';
       ?>
      
<div id="view" class="tabcontent">
  <h3>Misbehaviour </h3>
  <table id="" class="table table-bordered">
<thead>
<tr>
	<th>Admin's Email</th>
  <th>Warning Reason</th>
  
</tr>
</thead>
<?php
$sql = "SELECT * FROM miisbehave ";
$result = $conn->query($sql);

while($row = mysqli_fetch_array($result))
{
?>
<tr>
  <td><?php echo $row["AdminEmail"]; ?></td>
  <td><?php echo $row["reason"]; ?></td>
</tr>
<?php
}
?>
</table>
</div>

<div id="send" class="tabcontent">
  <h3>Send Warning </h3>
  <form method="post">
     <label for="AdminEmail">Admin's Email:</label>
    <!-- <input type="email" id="email" name="email">-->
     <select style="width: 50%; background-color: white; padding: 13px;" id="category" name="AdminEmail">
   <?php
     $cate = mysqli_query($conn,"SELECT AdminEmail FROM miisbehave ");
      while($row = mysqli_fetch_array($cate)) {
      ?>
            <option name="AdminEmail" style="color: teal;" value="<?php echo $row['AdminEmail']; ?>"><?php echo $row['AdminEmail']; ?></option>
        <?php 
      }
        ?>
</select>
     <br><br>
     <label for="reaosn">Warning Reason:</label>
     <input type="text" style="width: 50%; background-color: white; padding: 13px;" id="reason" name="reason">
     <br><br>
     <input  style="margin-left:30%; background-color:teal; padding:10px;" type="submit" id="submit" name="submit">
     </form>
     <?php
          if(isset($_POST["submit"]))
          {
               //$sql = "UPDATE customers 
               //SET has-warning= has-warning+1, warning='" . $_POST['reason'] . "' 
               //WHERE ut='ad', email='" . $_POST['email'] . "'";
               $sql = "UPDATE customers 
               SET  warning='{$_POST['reason'] }' 
               WHERE ut='ad'AND email='{$_POST['AdminEmail']}'";
               if ($conn->query($sql)) {
                    echo '<script>alert("warning has been given")</script>';  
                  } else {
                    echo "Error updating record: " . $conn->error;
                  }
          } 
     ?>
</div>


<script>
function openTAB(evt, tab) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  console.log(tabcontent);
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(tab).style.display = "block";
  evt.currentTarget.className += " active";
}
// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>

</div> <!-- End Middle Column -->
    
    <!-- Right Column -->
 
      
  
      
    <!-- End Right Column -->
    </div>
    
  <!-- End Grid -->
  </div>
  
<!-- End Page Container -->
</div>
<br>

<!-- Footer -->
<footer class="w3-container w3-theme-d3 w3-padding-16">
  <h5>Footer</h5>
</footer>



</body>
</html>