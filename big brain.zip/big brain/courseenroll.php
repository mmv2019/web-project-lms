<?php 

session_start();
$cid = $_GET['typec'];
$connect = mysqli_connect("localhost", "root", "", "bigbrain");  

$sql = "SELECT * FROM enrolled WHERE cid={$cid} ";  
$result = mysqli_query($connect, $sql);  
$row = mysqli_fetch_assoc($result);
$filepath=$row['pdf'];
if (isset($_POST['download'])) { 
if (file_exists($filepath)) {
  header('Content-Description: File Transfer');
  header('Content-Type: application/octet-stream');
  header('Content-Disposition: attachment; filename=' . basename($filepath));
  header('Expires: 0');
  header('Cache-Control: must-revalidate');
  header('Pragma: public');
  header('Content-Length: ' . filesize($filepath));
  readfile($filepath);
  exit;
}
}

?>

<html>
   <head>
<title> View Course</title><link rel="shortcut icon" type="image/png" href="logo1.png">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-teal.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans'>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/themes/smoothness/jquery-ui.min.css" />
<link rel="stylesheet" href="fontawesome/css/all.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
html, body, h1, h2, h3, h4, h5 {font-family: "Open Sans", sans-serif}

.nav{
    width:100%;
    z-index: -1;
    
}
.navbar{
    color:#0c9992;
}
.nav ul{
    display: flex;
    justify-content: center;
    list-style-type: none;
    height: 40px;
    background: #fff;
    box-shadow: 0px 2px 5px rgba(0,0,0,.3);
}



.nav ul li.active,
.tablink:hover{
    box-shadow: 0px -3px 0px teal inset;
    color:tomato;
}
/* Style tab links */
.tablink {

    width:100%;
  background-color: #555;
  color:black;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 14px 16px;
  font-size: 17px;
  width: 25%;
  display: flex;
    justify-content: center;
    list-style-type: none;
    height: 40px;
    background: #fff;
    box-shadow: 0px 2px 5px rgba(0,0,0,.3);
}

.tablink:hover {
  background-color: #777;
}

/* Style the tab content (and add height:100% for full page content) */
.tabcontent {
  color: black;
  display: none;
  padding: 100px 20px;
  height: 100%;
}




</style>
</head>
<body class="w3-theme-14">

<!-- Navbar -->
<?php include('profileheader.php'); ?>
<!-- Page Container -->
<div class="w3-container w3-content" style="max-width:1400px;margin-top:80px">    
  <!-- The Grid -->
  <div class="w3-row">
    <!-- Left Column -->
    <div class="w3-col m3">
      <!-- Profile -->
      <div class="w3-card w3-round w3-white">
        <div class="w3-container">
         <h4 class="w3-center">Course</h4>
         <p class="w3-center"><img src="<?php echo $row['img']; ?>" class="w3-circle" style="height:106px;width:106px" alt="Avatar"></p>
         <hr>
         <p><i class="fa fa-pencil fa-fw w3-margin-right w3-text-theme"></i><?php echo $row['course name'];?></p>
         <p><i class="fas fa-at fa-fw w3-margin-right w3-text-theme"></i> <?php echo $row['instructor'];?></p>
         <p><i class="far fa-clock fa-fw w3-margin-right w3-text-theme"></i> <?php echo $row['description'];?></p>
        </div>
      </div>
   
      <form method='POST' action='courseenroll.php'>
<input type="hidden" name="typec" value="<?php echo $_GET['cid']; ?>">
    </form>     
      <!-- Accordion -->
      <div class="w3-card w3-round w3-theme-d1">
        <div class="w3-theme">
       
         
          <div id="Demo2" class="w3-hide w3-container">
            <p>Some other text..</p>
          </div>

        </div>      
      </div>



     
      
   
    
    <!-- End Left Column -->
    </div>
    
       <!-- Middle Column -->
       <div class="w3-col m7">
    

 

        <div class="right-side"><div class="nav">
        <script src="web/nav.js"></script>
     
        <button class="tablink" onclick="openPage('Videos', this, '#0c9992')">Video</button>
<button class="tablink" onclick="openPage('PDFs', this, '#0c9992')" id="defaultOpen">PDFs</button>
<button class="tablink" onclick="openPage('Description', this, '#0c9992')">Description</button>
          
        </div>
        <div class="profile-body">
        <div id="Videos" class="tabcontent">


<h1>Video</h1>

<video  src="<?php echo  $row['video']; ?>" width="320" height="240" controls autoplay>
    <source id="source" type="video/*" style="width:30px;height:30px" src="<?php echo  $row['video']; ?>" >
</video>  
<script>
    function selectedVideo(self){
        var file = self.files[0];
        var reader = new FileReader();

        reader.onload = function(e){
            var src = e.target.result;
            var video = document.getElementById("video");
            var source = document.getElementById("source");

            source.setAttribute("src",src);
            video.load();
            video.play();
        }
    }
</script>
</div>

<div id="PDFs" class="tabcontent">


   <form method="POST">   <h3>Download the pdf:       <button type="submit" name="download" ><span class="glyphicon glyphicon-download"></button></h3></form>
 
</div>

<div id="Description" class="tabcontent">
 
   <h1>Course Description</h1>
                <p><?php echo $row['description'];?></p>
              

<script>
function openPage(pageName,elmnt,color) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].style.backgroundColor = "";
  }
  document.getElementById(pageName).style.display = "block";
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>
   
            
        </div>
    </div>
</div>

  <!-- End Middle Column -->
  
  </div>
  

    <br>
    
   
    
  <!-- End Right Column -->
  </div>
  
<!-- End Grid -->
</div>

<!-- End Page Container -->
</div>
<br>

<!-- Footer -->
<footer class="w3-container w3-theme-d3">
  <h5>Footer</h5>
</footer>

<footer class="w3-container w3-theme-d5">
<p></p>
</footer>

<script>
// Accordion
function myFunction(id) {
var x = document.getElementById(id);
if (x.className.indexOf("w3-show") == -1) {
  x.className += " w3-show";
  x.previousElementSibling.className += " w3-theme-d1";
} else { 
  x.className = x.className.replace("w3-show", "");
  x.previousElementSibling.className = 
  x.previousElementSibling.className.replace(" w3-theme-d1", "");
}
}

// Used to toggle the menu on smaller screens when clicking on the menu button
function openNav() {
var x = document.getElementById("navDemo");
if (x.className.indexOf("w3-show") == -1) {
  x.className += " w3-show";
} else { 
  x.className = x.className.replace(" w3-show", "");
}
}

</script>

</body>
</html> 
