
<?php
    include('homee.php');
    exit;
?>
