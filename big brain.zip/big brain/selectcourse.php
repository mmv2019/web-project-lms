<?php  
session_start();
 $connect = mysqli_connect("localhost", "root", "", "bigbrain");  
 $output = '';  
 $sql = "SELECT * FROM course";  
 $result = mysqli_query($connect, $sql);  
 $output .= '  
      <div id="myCourses" class="table-responsive ">  
           <table class="table table-bordered">  
                <tr> 
                <th >code</th>  
                     <th >name</th> 
                     <th >price</th>
                     <th >instructor</th>
                     <th >description</th>  
                     <th >Delete</th>  
                </tr>';  
 $rows = mysqli_num_rows($result);
 if($rows > 0)  
 {  
	  if($rows > 10)
	  {
		  $delete_records = $rows - 10;
		  $delete_sql = "DELETE FROM course LIMIT $delete_records";
		  mysqli_query($connect, $delete_sql);
	  }
      while($row = mysqli_fetch_array($result))  
      {  
           $output .= '  
                <tr>  
                     <td>'.$row["id"].'</td>  
                     <td class="coursename" name="coursename" id="coursename'.$row["id"].'" data-id1="'.$row["id"].'" contenteditable>'.$row["name"].'</td>  
                     <td class="price" name="price"  id="price'.$row["id"].'" data-id2="'.$row["id"].'" contenteditable>'.$row["price"].'</td> 
                     <td class="instructor" name="instructor"  id="instructor'.$row["id"].'" data-id3="'.$row["id"].'" contenteditable>'.$row["instructor"].'</td>  
                     <td class="description" name="description" id="description'.$row["id"].'"  data-id4="'.$row["id"].'" contenteditable>'.$row["description"].'</td> 
                     <td><button type="button" name="delete_btn" data-id3="'.$row["id"].'" class="btn btn-xs btn-danger btn_deletecourse">x</button>
                     <button type="button" name="edit_btn" id="edit_btn" data-id4="'.$row["id"].'" class="btn btn-xs btn-info btn_edit">Edit</button></td>  
                </tr>  
                
           ';  
           $_SESSION['coursecode']=$row['id'];
      }  
      $output .= '  
           <tr>  
                <td></td>  
                <td id="coursename" contenteditable></td>  
                <td id="price" contenteditable></td>
                <td id="instructor" contenteditable></td>  
                <td id="description" contenteditable></td>
                <td><button type="button" name="btn_addcourse" id="btn_addcourse" class="btn btn-xs btn-success">+</button></td>  
           </tr>  
      ';  
 }  
 else  
 {  
      $output .= '
				<tr>  
					<td></td>  
					<td id="name" contenteditable></td>  
          <td id="price" contenteditable></td>
          <td id="instructor" contenteditable></td>  
          <td id="description" contenteditable></td>
					<td><button type="button" name="btn_addcourse" id="btn_addcourse" class="btn btn-xs btn-success">+</button></td>  
			   </tr>';  
 }  
 $output .= '</table>  
      </div>';  
 echo $output;  
 ?>