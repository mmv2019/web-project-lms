<?php

//logout.php

session_start();
session_unset();

header("Location:homee.php");


?>